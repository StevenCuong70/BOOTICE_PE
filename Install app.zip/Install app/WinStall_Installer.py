"""
WinStall Installer - Cài ứng dụng Windows qua Winget
Phiên bản đơn giản, dễ hiểu, dễ sửa
"""

import shutil
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import threading
import os
import re
import io
import time
import hashlib
import colorsys
from datetime import datetime
from urllib.request import urlopen, Request

# Thử import Pillow (dùng để hiện icon đẹp)
try:
    from PIL import Image, ImageTk, ImageDraw, ImageFont, ImageEnhance
    CO_PILLOW = True
except ImportError:
    CO_PILLOW = False
    print("⚠️ Chưa có Pillow. Chạy: pip install Pillow để có icon đẹp")


# ============================================================
# PHẦN 1: DỮ LIỆU ỨNG DỤNG
# Sửa thêm/bớt app ở đây
# Mỗi danh mục có tên hiển thị và dict {tên app: winget ID}
# ============================================================

DANH_MUC_APP = {
    "🌐 Trình duyệt web": {
        "Google Chrome": "Google.Chrome",
        "Cốc Cốc": "CocCoc.CocCoc",
        "Mozilla Firefox": "Mozilla.Firefox",
        "Microsoft Edge": "Microsoft.Edge",
        "Brave Browser": "Brave.Brave",
        "Opera Browser": "Opera.Opera",
    },
    "💬 Liên lạc": {
        "Discord": "Discord.Discord",
        "Telegram Desktop": "Telegram.TelegramDesktop",
        "Zoom": "Zoom.Zoom",
        "Microsoft Teams": "Microsoft.Teams",
        "Skype": "Microsoft.Skype",
        "WhatsApp": "WhatsApp.WhatsApp",
        "Viber": "Viber.Viber",
    },
    "🎵 Nghe nhạc & Phim": {
        "CapCut": "ByteDance.CapCut",
        "VLC Media Player": "VideoLAN.VLC",
        "Spotify": "Spotify.Spotify",
        "iTunes": "Apple.iTunes",
        "Audacity": "Audacity.Audacity",
    },
    "🛠️ Lập trình": {
        "Visual Studio Code": "Microsoft.VisualStudioCode",
        "VS 2022 Community": "Microsoft.VisualStudio.2022.Community",
        "Python 3.12": "Python.Python.3.12",
        "Sublime Text 4": "SublimeHQ.SublimeText.4",
        "Notepad++": "Notepad++.Notepad++",
        "Node.js LTS": "OpenJS.NodeJS.LTS",
        "Java JDK 21": "Oracle.JDK.21",
        "Docker Desktop": "Docker.DockerDesktop",
        "Postman": "Postman.Postman",
        "Go": "GoLang.Go",
    },
    "📁 Quản lý tệp": {
        "7-Zip": "7zip.7zip",
        "WinRAR": "RARLab.WinRAR",
        "Everything": "voidtools.Everything",
        "WizTree": "AntibodySoftware.WizTree",
        "TreeSize Free": "JAMSoftware.TreeSize.Free",
    },
    "📝 Văn phòng": {
        "Office Deploy Tool": "Microsoft.OfficeDeploymentTool",
        "Acrobat Reader": "Adobe.Acrobat.Reader.64-bit",
        "Sumatra PDF": "SumatraPDF.SumatraPDF",
        "Foxit Reader": "Foxit.FoxitReader",
    },
    "🔒 Bảo mật & VPN": {
        "Malwarebytes": "Malwarebytes.Malwarebytes",
        "AdGuard": "Adguard.Adguard",
        "ESET Security": "ESET.Nod32",
        "Windscribe": "Windscribe.Windscribe",
    },
    "⚙️ Tiện ích hệ thống": {
        "CPU-Z": "CPUID.CPU-Z",
        "GPU-Z": "TechPowerUp.GPU-Z",
        "HWMonitor": "CPUID.HWMonitor",
        "HWiNFO": "REALiX.HWiNFO",
        "CrystalDiskInfo": "CrystalDewWorld.CrystalDiskInfo",
        "CrystalDiskMark": "CrystalDewWorld.CrystalDiskMark",
        "Rufus": "Rufus.Rufus",
        "Ventoy": "Ventoy.Ventoy",
        "MiniTool Partition": "MiniTool.PartitionWizard.Free",
        "Aomei Backupper": "AOMEI.Backupper.Standard",
        "Revo Uninstaller": "RevoUninstaller.RevoUninstaller",
        "Autoruns": "Microsoft.Sysinternals.Autoruns",
        "Process Explorer": "Microsoft.Sysinternals.ProcessExplorer",
    },
    "☁️ Lưu trữ đám mây": {
        "Google Drive": "Google.GoogleDrive",
        "Dropbox": "Dropbox.Dropbox",
        "OneDrive": "Microsoft.OneDrive",
        "MEGA": "Mega.MEGASync",
    },
    "🌍 Tải xuống": {
        "qBittorrent": "qBittorrent.qBittorrent",
        "Internet Download Manager": "Tonec.InternetDownloadManager",
    },
    "🖥️ Điều khiển từ xa & VM": {
        "AnyDesk": "AnyDeskSoftware.AnyDesk",
        "TeamViewer": "TeamViewer.TeamViewer",
        "RustDesk": "RustDesk.RustDesk",
        "VirtualBox": "Oracle.VirtualBox",
    },
    "📹 Quay phim & Streaming": {
        "OBS Studio": "OBSProject.OBSStudio",
        "StreamLabs": "Streamlabs.Streamlabs",
        "Shotcut": "Meltytech.Shotcut",
        "FFmpeg": "Gyan.FFmpeg",
        "yt-dlp": "yt-dlp.yt-dlp",
        "4K Downloader": "OpenMedia.4KVideoDownloader",
    },
    "🔧 Bộ chạy nền (Runtime)": {
        ".NET 8 Runtime": "Microsoft.DotNet.DesktopRuntime.8",
        ".NET 8 SDK": "Microsoft.DotNet.SDK.8",
        "VC++ Redist": "Microsoft.VCRedist.2015+.x64",
        "DirectX": "Microsoft.DirectX",
    },
}


# ============================================================
# PHẦN 2: MÀU SẮC
# Sửa màu giao diện ở đây
# ============================================================

MAU = {
    'nen_toi': '#0a0a18',        # Nền tối nhất
    'nen_chinh': '#13132a',      # Nền chính
    'nen_the': '#1c1c3d',        # Nền thẻ app
    'nen_the_hover': '#252550',  # Nền thẻ khi rê chuột
    'nen_menu': '#0f0f23',       # Nền menu bên trái
    'nen_header': '#0d0d20',     # Nền thanh trên
    'tim': '#5f4bb6',            # Màu tím chủ đạo
    'xanh_dam': '#0f3460',       # Xanh đậm
    'do': '#e94560',             # Đỏ nổi bật
    'do_sang': '#ff6b81',        # Đỏ sáng
    'chu': '#eaeaef',            # Màu chữ thường
    'chu_mo': '#8888aa',         # Chữ mờ
    'chu_sang': '#ffffff',       # Chữ sáng
    'xanh_la': '#00d464',        # Xanh lá (thành công)
    'vang': '#ffc93c',           # Vàng (cảnh báo)
    'do_loi': '#ff4766',         # Đỏ (lỗi)
    'xanh_cyan': '#2ee5e5',     # Xanh cyan
    'vien': '#2a2a55',           # Viền
    'da_cai': '#1b5e20',         # Xanh đậm (đã cài)
    'nut_cai': '#0d47a1',        # Nút cài đặt
    'nut_cai_hover': '#1565c0',  # Nút cài khi hover
}


# ============================================================
# PHẦN 3: TẠO ICON ĐƠN GIẢN (chữ cái đầu)
# Nếu không có Pillow thì bỏ qua icon
# ============================================================

def tao_icon_chu_cai(ky_tu, winget_id, kich_thuoc=36):
    """Tạo icon hình vuông bo góc với chữ cái đầu của app"""
    if not CO_PILLOW:
        return None

    # Tạo màu ngẫu nhiên dựa trên tên app
    ma_hash = int(hashlib.md5(winget_id.encode()).hexdigest()[:6], 16) % 360
    r, g, b = colorsys.hsv_to_rgb(ma_hash / 360, 0.55, 0.82)
    mau_nen = (int(r * 255), int(g * 255), int(b * 255))

    # Vẽ ảnh lớn rồi thu nhỏ cho đẹp
    kich_thuoc_ve = kich_thuoc * 4
    anh = Image.new('RGBA', (kich_thuoc_ve, kich_thuoc_ve), (0, 0, 0, 0))
    ve = ImageDraw.Draw(anh)

    # Vẽ hình chữ nhật bo góc
    ve.rounded_rectangle(
        [0, 0, kich_thuoc_ve - 1, kich_thuoc_ve - 1],
        radius=int(kich_thuoc_ve * 0.22),
        fill=mau_nen
    )

    # Chọn font chữ
    try:
        font = ImageFont.truetype("segoeuib.ttf", int(kich_thuoc_ve * 0.52))
    except Exception:
        try:
            font = ImageFont.truetype("arial.ttf", int(kich_thuoc_ve * 0.52))
        except Exception:
            font = ImageFont.load_default()

    # Vẽ chữ cái giữa hình
    hop = ve.textbbox((0, 0), ky_tu.upper(), font=font)
    rong_chu = hop[2] - hop[0]
    cao_chu = hop[3] - hop[1]
    vi_tri_x = (kich_thuoc_ve - rong_chu) // 2
    vi_tri_y = (kich_thuoc_ve - cao_chu) // 2 - hop[1]
    ve.text((vi_tri_x, vi_tri_y), ky_tu.upper(),
            fill=(255, 255, 255, 240), font=font)

    # Thu nhỏ về kích thước cần
    anh = anh.resize((kich_thuoc, kich_thuoc), Image.LANCZOS)
    return ImageTk.PhotoImage(anh)

def tai_icon_tu_mang(winget_id, ten_app, thu_muc_icon):
    """
    Tải icon từ winstall.app (ưu tiên) → Google favicon (dự phòng).
    Thử nhiều URL vì mỗi app có kiểu link khác nhau.
    Trả về dữ liệu ảnh (bytes) hoặc None.
    """

    # ══════════════════════════════════════════════════════
    # BẢNG 1: SLUG đặc biệt trên winstall.app
    # (slug khác với winget ID → phải map thủ công)
    # ══════════════════════════════════════════════════════
    SLUG_DAC_BIET = {
        "Google.Chrome": "chrome",
        "Mozilla.Firefox": "firefox",
        "Microsoft.Edge": "microsoft-edge",
        "Brave.Brave": "brave",
        "Opera.Opera": "opera",
        "CocCoc.CocCoc": "Cốc Cốc",
        "Discord.Discord": "discord",
        "Telegram.TelegramDesktop": "telegram",
        "Zoom.Zoom": "zoom",
        "Microsoft.Teams": "microsoft-teams",
        "Microsoft.Skype": "skype",
        "WhatsApp.WhatsApp": "whatsapp",
        "Viber.Viber": "viber",
        "ByteDance.CapCut": "capcut",
        "VideoLAN.VLC": "vlc",
        "Spotify.Spotify": "spotify",
        "Apple.iTunes": "itunes",
        "Audacity.Audacity": "audacity",
        "Microsoft.VisualStudioCode": "visual-studio-code",
        "Microsoft.VisualStudio.2022.Community": "visual-studio",
        "OpenJS.NodeJS.LTS": "nodejs",
        "Python.Python.3.12": "python",
        "Oracle.JDK.21": "java",
        "Docker.DockerDesktop": "docker",
        "Postman.Postman": "postman",
        "Microsoft.WindowsTerminal": "windows-terminal",
        "Microsoft.PowerShell": "powershell",
        "SublimeHQ.SublimeText.4": "sublime-text",
        "Notepad++.Notepad++": "notepad-plus-plus",
        "GoLang.Go": "go",
        "Git.Git": "git",
        "7zip.7zip": "7-zip",
        "RARLab.WinRAR": "winrar",
        "Giorgiotani.Peazip": "peazip",
        "voidtools.Everything": "everything",
        "AntibodySoftware.WizTree": "wiztree",
        "JAMSoftware.TreeSize.Free": "treesize-free",
        "Microsoft.OfficeDeploymentTool": "office-deployment-tool",
        "Microsoft.OneDrive": "onedrive",
        "Adobe.Acrobat.Reader.64-bit": "adobe-acrobat-reader",
        "SumatraPDF.SumatraPDF": "sumatrapdf",
        "Foxit.FoxitReader": "foxit-reader",
        "Malwarebytes.Malwarebytes": "malwarebytes",
        "AdGuard.AdGuard": "AdGuard",
        "Adguard.Adguard": "AdGuard",
        "ESET.Nod32": "eset-nod32",
        "Windscribe.Windscribe": "windscribe",
        "CPUID.CPU-Z": "cpu-z",
        "TechPowerUp.GPU-Z": "gpu-z",
        "CPUID.HWMonitor": "hwmonitor",
        "REALiX.HWiNFO": "hwinfo",
        "CrystalDewWorld.CrystalDiskInfo": "crystaldiskinfo",
        "CrystalDewWorld.CrystalDiskMark": "crystaldiskmark",
        "Rufus.Rufus": "rufus",
        "Ventoy.Ventoy": "ventoy",
        "MiniTool.PartitionWizard.Free": "minitool-partition-wizard",
        "AOMEI.Backupper.Standard": "aomei-backupper-standard",
        "RevoUninstaller.RevoUninstaller": "revo-uninstaller",
        "Microsoft.Sysinternals.Autoruns": "autoruns",
        "Microsoft.Sysinternals.ProcessExplorer": "process-explorer",
        "Google.GoogleDrive": "google-drive",
        "Dropbox.Dropbox": "dropbox",
        "Mega.MEGASync": "megasync",
        "qBittorrent.qBittorrent": "qbittorrent",
        "Tonec.InternetDownloadManager": "internet-download-manager",
        "AnyDeskSoftware.AnyDesk": "anydesk",
        "TeamViewer.TeamViewer": "teamviewer",
        "RustDesk.RustDesk": "rustdesk",
        "Oracle.VirtualBox": "virtualbox",
        "OBSProject.OBSStudio": "obs-studio",
        "Streamlabs.Streamlabs": "streamlabs",
        "Meltytech.Shotcut": "shotcut",
        "Gyan.FFmpeg": "ffmpeg",
        "yt-dlp.yt-dlp": "yt-dlp",
        "OpenMedia.4KVideoDownloader": "4k-video-downloader",
        "Microsoft.DotNet.DesktopRuntime.8": "dotnet-desktop-runtime",
        "Microsoft.DotNet.SDK.8": "dotnet-sdk",
        "Microsoft.VCRedist.2015+.x64": "visual-c-plus-plus",
        "Microsoft.DirectX": "directx",
    }

    # ══════════════════════════════════════════════════════
    # BẢNG 2: URL CỐ ĐỊNH cho các app khó tải
    # (một số app phải dùng link riêng, không theo quy luật)
    # ══════════════════════════════════════════════════════
    URL_CO_DINH = {
        "Google.Chrome": "https://winstall.app/assets/apps/chrome.webp",
        "Microsoft.Edge": "https://winstall.app/assets/apps/edge.webp",
        "Mozilla.Firefox": "https://winstall.app/assets/apps/firefox.webp",
        "CrystalDewWorld.CrystalDiskMark":
            "https://api.winstall.app/icons/next/CrystalDewWorld.CrystalDiskMark.webp",
        "CrystalDewWorld.CrystalDiskInfo":
            "https://api.winstall.app/icons/next/CrystalDewWorld.CrystalDiskInfo.webp",
        "MiniTool.PartitionWizard.Free":
            "https://api.winstall.app/icons/next/MiniTool.PartitionWizard.Free.webp",
        "AOMEI.Backupper.Standard":
            "https://api.winstall.app/icons/next/AOMEI.Backupper.Standard.webp",
    }

    # ══════════════════════════════════════════════════════
    # BẢNG 3: DOMAIN để lấy favicon (dự phòng cuối)
    # ══════════════════════════════════════════════════════
    DOMAIN_APP = {
        "Google.Chrome": "google.com",
        "Mozilla.Firefox": "mozilla.org",
        "Microsoft.Edge": "microsoft.com",
        "Brave.Brave": "brave.com",
        "Opera.Opera": "opera.com",
        "Discord.Discord": "discord.com",
        "Telegram.TelegramDesktop": "telegram.org",
        "Zoom.Zoom": "zoom.us",
        "Microsoft.Teams": "teams.microsoft.com",
        "Microsoft.Skype": "skype.com",
        "WhatsApp.WhatsApp": "whatsapp.com",
        "Viber.Viber": "viber.com",
        "ByteDance.CapCut": "capcut.com",
        "VideoLAN.VLC": "videolan.org",
        "Spotify.Spotify": "spotify.com",
        "Apple.iTunes": "apple.com",
        "Audacity.Audacity": "audacityteam.org",
        "Microsoft.VisualStudioCode": "code.visualstudio.com",
        "OpenJS.NodeJS.LTS": "nodejs.org",
        "Python.Python.3.12": "python.org",
        "Oracle.JDK.21": "oracle.com",
        "Docker.DockerDesktop": "docker.com",
        "Postman.Postman": "postman.com",
        "SublimeHQ.SublimeText.4": "sublimetext.com",
        "Notepad++.Notepad++": "notepad-plus-plus.org",
        "GoLang.Go": "go.dev",
        "Git.Git": "git-scm.com",
        "7zip.7zip": "7-zip.org",
        "RARLab.WinRAR": "win-rar.com",
        "voidtools.Everything": "voidtools.com",
        "Microsoft.OneDrive": "onedrive.live.com",
        "Adobe.Acrobat.Reader.64-bit": "adobe.com",
        "SumatraPDF.SumatraPDF": "sumatrapdfreader.org",
        "Foxit.FoxitReader": "foxit.com",
        "Malwarebytes.Malwarebytes": "malwarebytes.com",
        "Adguard.Adguard": "adguard.com",
        "ESET.Nod32": "eset.com",
        "Windscribe.Windscribe": "windscribe.com",
        "CPUID.CPU-Z": "cpuid.com",
        "TechPowerUp.GPU-Z": "techpowerup.com",
        "REALiX.HWiNFO": "hwinfo.com",
        "CrystalDewWorld.CrystalDiskInfo": "crystalmark.info",
        "Rufus.Rufus": "rufus.ie",
        "Ventoy.Ventoy": "ventoy.net",
        "Google.GoogleDrive": "drive.google.com",
        "Dropbox.Dropbox": "dropbox.com",
        "Mega.MEGASync": "mega.io",
        "qBittorrent.qBittorrent": "qbittorrent.org",
        "AnyDeskSoftware.AnyDesk": "anydesk.com",
        "TeamViewer.TeamViewer": "teamviewer.com",
        "RustDesk.RustDesk": "rustdesk.com",
        "Oracle.VirtualBox": "virtualbox.org",
        "OBSProject.OBSStudio": "obsproject.com",
        "Streamlabs.Streamlabs": "streamlabs.com",
        "Meltytech.Shotcut": "shotcut.org",
        "Gyan.FFmpeg": "ffmpeg.org",
        "OpenMedia.4KVideoDownloader": "4kdownload.com",
    }

    headers = {
        'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/125.0.0.0 Safari/537.36'),
        'Accept': 'image/webp,image/png,image/*,*/*',
    }

    # Hàm nhỏ: thử tải 1 URL
    def thu_tai(url):
        try:
            req = Request(url, headers=headers)
            resp = urlopen(req, timeout=8)
            du_lieu = resp.read()
            if len(du_lieu) > 200:  # Bỏ ảnh quá nhỏ (có thể lỗi)
                return du_lieu
        except Exception:
            pass
        return None

    # ══════════════════════════════════════════════════════
    # BƯỚC 1: Thử URL cố định trước (cho app khó tải)
    # ══════════════════════════════════════════════════════
    if winget_id in URL_CO_DINH:
        du_lieu = thu_tai(URL_CO_DINH[winget_id])
        if du_lieu:
            return du_lieu

    # ══════════════════════════════════════════════════════
    # BƯỚC 2: Tạo danh sách slug để thử trên winstall.app
    # ══════════════════════════════════════════════════════
    ds_slug = []

    # (a) Slug đặc biệt (nếu có trong bảng)
    if winget_id in SLUG_DAC_BIET:
        ds_slug.append(SLUG_DAC_BIET[winget_id])

    # (b) Tự tạo slug từ tên app (vd: "Google Chrome" → "google-chrome")
    slug_tu_ten = ten_app.lower().strip()
    for ky_tu in " .+()[]{}!@#$%^&*='\";:/\\|?<>,":
        slug_tu_ten = slug_tu_ten.replace(ky_tu, "-")
    while "--" in slug_tu_ten:
        slug_tu_ten = slug_tu_ten.replace("--", "-")
    slug_tu_ten = slug_tu_ten.strip("-")
    if slug_tu_ten and slug_tu_ten not in ds_slug:
        ds_slug.append(slug_tu_ten)

    # (c) Phần cuối winget_id (vd: "Google.Chrome" → "chrome")
    phan = winget_id.split(".")
    if len(phan) >= 2:
        slug_cuoi = phan[-1].lower().replace("+", "-plus").strip("-")
        if slug_cuoi and slug_cuoi not in ds_slug:
            ds_slug.append(slug_cuoi)

    # ══════════════════════════════════════════════════════
    # BƯỚC 3: Thử tải từ winstall.app (nhiều kiểu URL)
    # ══════════════════════════════════════════════════════
    # Kiểu A: dùng winget_id đầy đủ (API mới)
    du_lieu = thu_tai(f"https://api.winstall.app/icons/next/{winget_id}.webp")
    if du_lieu:
        return du_lieu

    # Kiểu B: dùng slug ngắn
    for slug in ds_slug:
        # B1: API chính
        du_lieu = thu_tai(f"https://api.winstall.app/icons/{slug}.webp")
        if du_lieu:
            return du_lieu

        # B2: Assets trực tiếp
        du_lieu = thu_tai(f"https://winstall.app/assets/apps/{slug}.webp")
        if du_lieu:
            return du_lieu

    # ══════════════════════════════════════════════════════
    # BƯỚC 4: Dự phòng cuối - tải favicon từ domain
    # ══════════════════════════════════════════════════════
    domain = DOMAIN_APP.get(winget_id)

    # Nếu chưa có domain, đoán từ winget_id
    if not domain:
        phan = winget_id.split('.')
        if len(phan) >= 2:
            domain = f"{phan[0].lower()}.com"

    if domain:
        # Thử 3 dịch vụ favicon
        for url in [
            f"https://www.google.com/s2/favicons?domain={domain}&sz=128",
            f"https://icons.duckduckgo.com/ip3/{domain}.ico",
            f"https://logo.clearbit.com/{domain}",
        ]:
            du_lieu = thu_tai(url)
            if du_lieu:
                return du_lieu

    # Không tải được từ nguồn nào
    return None

# ============================================================
# PHẦN 4: ỨNG DỤNG CHÍNH
# ============================================================

class UngDungCaiDat:
    """Ứng dụng cài đặt phần mềm qua Winget"""

    def __init__(self, root):
        self.root = root
        self.root.title("⚡ WinStall Installer Winget Windows")
        self.root.geometry("980x750")
        self.root.configure(bg=MAU['nen_chinh'])

        # --- Biến lưu trạng thái ---
        self.danh_muc_hien_tai = None       # Danh mục đang chọn
        self.app_da_chon = set()            # Các app đã tick
        self.trang_thai_cai = {}            # Cache trạng thái: {winget_id: True/False}
        self.widget_app = {}                # Widget của từng app: {winget_id: dict}
        self.bien_tick = {}                 # BooleanVar của checkbox: {winget_id: var}
        self.nut_danh_muc = {}              # Widget nút danh mục: {tên: (frame, label)}
        self.cache_icon = {}                # Cache icon đã tạo

        # Thư mục lưu icon
        self.thu_muc_icon = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "images"
        )
        os.makedirs(self.thu_muc_icon, exist_ok=True)

        # --- Xây dựng giao diện ---
        self.tao_giao_dien()

        # --- Kiểm tra winget ---
        self.kiem_tra_winget()

    # ========================================================
    # 4.1: TẠO GIAO DIỆN
    # ========================================================

    def tao_giao_dien(self):
        """Tạo toàn bộ giao diện, gọi các hàm con"""
        self.tao_thanh_tren()
        self.tao_vach_ngang()
        self.tao_phan_chinh()
        self.tao_phan_log()

    def tao_thanh_tren(self):
        """Tạo thanh header phía trên cùng"""
        header = tk.Frame(self.root, bg=MAU['nen_header'], height=72)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        khung = tk.Frame(header, bg=MAU['nen_header'])
        khung.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        # Bên trái: Logo + tiêu đề
        ben_trai = tk.Frame(khung, bg=MAU['nen_header'])
        ben_trai.pack(side=tk.LEFT)

        tk.Label(
            ben_trai, text="⚡", font=("Segoe UI Emoji", 26),
            bg=MAU['nen_header'], fg=MAU['do']
        ).pack(side=tk.LEFT, padx=(0, 10))

        tk.Label(
            ben_trai, text="WinStall Installer Winget Windows",
            font=("Segoe UI", 15, "bold"),
            bg=MAU['nen_header'], fg=MAU['chu_sang']
        ).pack(side=tk.LEFT)

        # Bên phải: Trạng thái + nút làm mới
        ben_phai = tk.Frame(khung, bg=MAU['nen_header'])
        ben_phai.pack(side=tk.RIGHT)

        self.nhan_trang_thai = tk.Label(
            ben_phai, text="⏳ Đang kiểm tra winget...",
            font=("Segoe UI", 9), bg=MAU['nen_header'], fg=MAU['chu_mo']
        )
        self.nhan_trang_thai.pack(side=tk.RIGHT, padx=(10, 0))

        tk.Button(
            ben_phai, text="🔄 Làm mới", font=("Segoe UI", 9),
            bg=MAU['tim'], fg="white", bd=0, padx=10, pady=4,
            cursor="hand2", command=self.lam_moi
        ).pack(side=tk.RIGHT, padx=4)

    def tao_vach_ngang(self):
        """Tạo vạch đỏ phân cách header và nội dung"""
        tk.Frame(self.root, bg=MAU['do'], height=2).pack(fill=tk.X, pady=5)

    def tao_phan_chinh(self):
        """Tạo phần chính: menu trái + danh sách app phải"""
        khung_chinh = tk.PanedWindow(
            self.root, orient=tk.HORIZONTAL,
            bg=MAU['vien'], sashwidth=2, bd=0
        )
        khung_chinh.pack(fill=tk.BOTH, expand=True)

        # --- MENU BÊN TRÁI ---
        menu_trai = tk.Frame(khung_chinh, bg=MAU['nen_menu'], width=245)
        khung_chinh.add(menu_trai, width=250, minsize=200)
        self.tao_menu_trai(menu_trai)

        # --- DANH SÁCH APP BÊN PHẢI ---
        khung_phai = tk.Frame(khung_chinh, bg=MAU['nen_chinh'])
        khung_chinh.add(khung_phai)
        self.tao_khung_phai(khung_phai)

    # --------------------------------------------------------
    # 4.1a: Menu bên trái (danh mục + tìm kiếm)
    # --------------------------------------------------------

    def tao_menu_trai(self, cha):
        """Tạo menu bên trái gồm: ô tìm kiếm + danh sách danh mục"""

        # --- Ô tìm kiếm ---
        khung_tim = tk.Frame(cha, bg=MAU['nen_menu'])
        khung_tim.pack(fill=tk.X, padx=10, pady=(12, 6))

        khung_o_tim = tk.Frame(
            khung_tim, bg=MAU['nen_the'],
            highlightbackground=MAU['vien'], highlightthickness=1
        )
        khung_o_tim.pack(fill=tk.X)

        tk.Label(
            khung_o_tim, text="🔍", font=("Segoe UI Emoji", 11),
            bg=MAU['nen_the'], fg=MAU['chu_mo']
        ).pack(side=tk.LEFT, padx=(8, 0))

        self.bien_tim_kiem = tk.StringVar()
        self.bien_tim_kiem.trace('w', self.xu_ly_tim_kiem)

        tk.Entry(
            khung_o_tim, textvariable=self.bien_tim_kiem,
            font=("Segoe UI", 10), bg=MAU['nen_the'], fg=MAU['chu'],
            insertbackground=MAU['chu'], bd=0
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 8), ipady=6)

        # --- Tiêu đề "DANH MỤC" ---
        tk.Frame(cha, bg=MAU['vien'], height=1).pack(fill=tk.X, padx=10, pady=4)
        tk.Label(
            cha, text="  DANH MỤC", font=("Segoe UI", 8, "bold"),
            bg=MAU['nen_menu'], fg=MAU['chu_mo']
        ).pack(anchor=tk.W, padx=10, pady=(4, 2))

        # --- Danh sách danh mục (cuộn được) ---
        khung_cuon = tk.Frame(cha, bg=MAU['nen_menu'])
        khung_cuon.pack(fill=tk.BOTH, expand=True, padx=4)

        self.canvas_menu = tk.Canvas(
            khung_cuon, bg=MAU['nen_menu'], highlightthickness=0, bd=0
        )
        thanh_cuon = ttk.Scrollbar(
            khung_cuon, orient=tk.VERTICAL, command=self.canvas_menu.yview
        )
        self.khung_trong_menu = tk.Frame(self.canvas_menu, bg=MAU['nen_menu'])

        self.khung_trong_menu.bind("<Configure>", lambda e:
            self.canvas_menu.configure(
                scrollregion=self.canvas_menu.bbox("all")
            ))
        self.canvas_menu.create_window(
            (0, 0), window=self.khung_trong_menu, anchor=tk.NW
        )
        self.canvas_menu.configure(yscrollcommand=thanh_cuon.set)
        self.canvas_menu.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        thanh_cuon.pack(side=tk.RIGHT, fill=tk.Y)

        # Cuộn bằng chuột
        self.canvas_menu.bind("<Enter>", lambda e:
            self.canvas_menu.bind_all("<MouseWheel>", lambda ev:
                self.canvas_menu.yview_scroll(int(-1 * ev.delta / 120), "units")
            ))
        self.canvas_menu.bind("<Leave>", lambda e:
            self.canvas_menu.unbind_all("<MouseWheel>"))

        # Tạo từng nút danh mục
        for ten_dm in DANH_MUC_APP:
            self.tao_nut_danh_muc(ten_dm)

        # --- Thông tin ở đáy menu ---
        tong_app = sum(len(apps) for apps in DANH_MUC_APP.values())
        khung_day = tk.Frame(cha, bg=MAU['nen_toi'])
        khung_day.pack(fill=tk.X, side=tk.BOTTOM)
        tk.Frame(khung_day, bg=MAU['vien'], height=1).pack(fill=tk.X)
        tk.Label(
            khung_day,
            text=f"📦 {tong_app} ứng dụng · {len(DANH_MUC_APP)} danh mục",
            font=("Segoe UI", 8, "bold"),
            bg=MAU['nen_toi'], fg=MAU['chu']
        ).pack(pady=(6, 6))

    def tao_nut_danh_muc(self, ten):
        """Tạo 1 nút danh mục trong menu trái"""
        so_app = len(DANH_MUC_APP[ten])

        khung = tk.Frame(self.khung_trong_menu, bg=MAU['nen_menu'], cursor="hand2")
        khung.pack(fill=tk.X, padx=4, pady=1)

        nhan = tk.Label(
            khung, text=f"  {ten}", font=("Segoe UI", 10),
            bg=MAU['nen_menu'], fg=MAU['chu'],
            anchor=tk.W, padx=8, pady=7
        )
        nhan.pack(side=tk.LEFT, fill=tk.X, expand=True)

        so = tk.Label(
            khung, text=str(so_app), font=("Segoe UI", 8, "bold"),
            bg=MAU['xanh_dam'], fg="white", padx=6, pady=1
        )
        so.pack(side=tk.RIGHT, padx=(0, 8), pady=4)

        # Khi click vào danh mục
        def khi_click(e, t=ten):
            self.chon_danh_muc(t)

        # Khi rê chuột vào
        def khi_vao(e):
            if self.danh_muc_hien_tai != ten:
                khung.configure(bg=MAU['nen_the_hover'])
                nhan.configure(bg=MAU['nen_the_hover'], fg=MAU['xanh_cyan'])

        # Khi rê chuột ra
        def khi_ra(e):
            if self.danh_muc_hien_tai != ten:
                khung.configure(bg=MAU['nen_menu'])
                nhan.configure(bg=MAU['nen_menu'], fg=MAU['chu'])

        for w in (khung, nhan, so):
            w.bind("<Button-1>", khi_click)
            w.bind("<Enter>", khi_vao)
            w.bind("<Leave>", khi_ra)

        self.nut_danh_muc[ten] = (khung, nhan, so)

    # --------------------------------------------------------
    # 4.1b: Khung bên phải (thanh nút + danh sách app)
    # --------------------------------------------------------

    def tao_khung_phai(self, cha):
        """Tạo khung bên phải: thanh nút hành động + danh sách app"""

        # --- Thanh nút hành động ---
        thanh_nut = tk.Frame(cha, bg=MAU['nen_header'], height=52)
        thanh_nut.pack(fill=tk.X)
        thanh_nut.pack_propagate(False)

        khung_nut = tk.Frame(thanh_nut, bg=MAU['nen_header'])
        khung_nut.pack(fill=tk.BOTH, expand=True, padx=14, pady=8)

        # Tiêu đề danh mục đang chọn
        self.tieu_de_danh_muc = tk.Label(
            khung_nut, text="👈 Chọn danh mục bên trái",
            font=("Segoe UI", 13, "bold"),
            bg=MAU['nen_header'], fg=MAU['chu_sang']
        )
        self.tieu_de_danh_muc.pack(side=tk.LEFT)

        # Nút "Cài đã chọn"
        self.nut_cai_chon = tk.Button(
            khung_nut, text="📥 Cài đã chọn (0)",
            font=("Segoe UI", 10, "bold"),
            bg="#555", fg="white", bd=0, padx=12, pady=5,
            cursor="hand2", command=self.cai_nhieu_app
        )
        self.nut_cai_chon.pack(side=tk.RIGHT, padx=(6, 0))

        # Nút "Chọn hết" và "Bỏ chọn"
        tk.Button(
            khung_nut, text="☑ Chọn hết", font=("Segoe UI", 9),
            bg=MAU['xanh_dam'], fg="white", bd=0, padx=10, pady=4,
            cursor="hand2", command=self.chon_tat_ca
        ).pack(side=tk.RIGHT, padx=3)

        tk.Button(
            khung_nut, text="☐ Bỏ chọn", font=("Segoe UI", 9),
            bg=MAU['xanh_dam'], fg="white", bd=0, padx=10, pady=4,
            cursor="hand2", command=self.bo_chon_tat_ca
        ).pack(side=tk.RIGHT, padx=3)

        # --- Danh sách app (cuộn được) ---
        khung_app = tk.Frame(cha, bg=MAU['nen_chinh'])
        khung_app.pack(fill=tk.BOTH, expand=True)

        self.canvas_app = tk.Canvas(
            khung_app, bg=MAU['nen_chinh'], highlightthickness=0, bd=0
        )
        thanh_cuon = ttk.Scrollbar(
            khung_app, orient=tk.VERTICAL, command=self.canvas_app.yview
        )

        self.khung_ds_app = tk.Frame(self.canvas_app, bg=MAU['nen_chinh'])
        self.khung_ds_app.bind("<Configure>", lambda e:
            self.canvas_app.configure(
                scrollregion=self.canvas_app.bbox("all")
            ))
        self.id_cua_so = self.canvas_app.create_window(
            (0, 0), window=self.khung_ds_app, anchor=tk.NW
        )
        self.canvas_app.configure(yscrollcommand=thanh_cuon.set)

        # Tự co giãn theo chiều ngang
        self.canvas_app.bind("<Configure>", lambda e:
            self.canvas_app.itemconfig(self.id_cua_so, width=e.width))

        self.canvas_app.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        thanh_cuon.pack(side=tk.RIGHT, fill=tk.Y)

        # Cuộn bằng chuột
        self.canvas_app.bind("<Enter>", lambda e:
            self.canvas_app.bind_all("<MouseWheel>", lambda ev:
                self.canvas_app.yview_scroll(int(-1 * ev.delta / 120), "units")
            ))
        self.canvas_app.bind("<Leave>", lambda e:
            self.canvas_app.unbind_all("<MouseWheel>"))

        # Hiện màn chào
        self.hien_man_chao()

    def hien_man_chao(self):
        """Hiện trang chào mừng khi chưa chọn danh mục"""
        # Xóa nội dung cũ
        for w in self.khung_ds_app.winfo_children():
            w.destroy()

        khung = tk.Frame(self.khung_ds_app, bg=MAU['nen_chinh'])
        khung.pack(expand=True, fill=tk.BOTH, pady=80)

        tk.Label(
            khung, text="⚡", font=("Segoe UI Emoji", 60),
            bg=MAU['nen_chinh'], fg=MAU['do']
        ).pack()
        tk.Label(
            khung, text="Chào mừng bạn đến với WinStall Installer",
            font=("Segoe UI", 14, "bold"),
            bg=MAU['nen_chinh'], fg=MAU['chu_sang']
        ).pack(pady=(10, 4))
        tk.Label(
            khung, text="👈 Chọn một danh mục bên trái để bắt đầu",
            font=("Segoe UI", 11),
            bg=MAU['nen_chinh'], fg=MAU['chu_mo']
        ).pack()
        tk.Label(
            khung, text="hoặc dùng ô tìm kiếm để tìm ứng dụng",
            font=("Segoe UI", 10),
            bg=MAU['nen_chinh'], fg=MAU['chu_mo']
        ).pack(pady=(2, 20))

    # --------------------------------------------------------
    # 4.1c: Phần log (nhật ký) ở dưới cùng
    # --------------------------------------------------------

    def tao_phan_log(self):
        """Tạo phần nhật ký ở dưới cùng"""
        khung_log = tk.Frame(self.root, bg=MAU['nen_toi'])
        khung_log.pack(fill=tk.X, side=tk.BOTTOM)

        tk.Frame(khung_log, bg=MAU['vien'], height=1).pack(fill=tk.X)

        # Thanh điều khiển log
        thanh_dk = tk.Frame(khung_log, bg=MAU['nen_toi'])
        thanh_dk.pack(fill=tk.X)

        self.log_dang_hien = True
        self.nut_an_log = tk.Button(
            thanh_dk, text="📋 Nhật ký ▼",
            font=("Segoe UI", 8, "bold"),
            bg=MAU['nen_toi'], fg=MAU['chu'], bd=0, cursor="hand2",
            command=self.an_hien_log
        )
        self.nut_an_log.pack(side=tk.LEFT, padx=10, pady=4)

        # Thanh tiến trình
        self.bien_tien_trinh = tk.DoubleVar()
        ttk.Progressbar(
            thanh_dk, variable=self.bien_tien_trinh, maximum=100,
            length=180
        ).pack(side=tk.RIGHT, padx=10, pady=4)

        self.nhan_tien_trinh = tk.Label(
            thanh_dk, text="Sẵn sàng", font=("Segoe UI", 8),
            bg=MAU['nen_toi'], fg=MAU['chu_mo']
        )
        self.nhan_tien_trinh.pack(side=tk.RIGHT, padx=4)

        # Nút xóa log
        tk.Button(
            thanh_dk, text="🗑️ Xóa", font=("Segoe UI", 8),
            bg=MAU['nen_toi'], fg=MAU['chu_mo'], bd=0, cursor="hand2",
            command=self.xoa_log
        ).pack(side=tk.RIGHT, padx=4)

        # Khung chứa text log
        self.khung_log = tk.Frame(khung_log, bg=MAU['nen_toi'])
        self.khung_log.pack(fill=tk.X)

        self.o_log = scrolledtext.ScrolledText(
            self.khung_log, height=6, bg="#070718", fg=MAU['chu'],
            font=("Cascadia Code", 9), insertbackground=MAU['chu'],
            selectbackground=MAU['tim'], relief=tk.FLAT, bd=0, wrap=tk.WORD
        )
        self.o_log.pack(fill=tk.X, padx=10, pady=(0, 8))

        # Cấu hình màu cho các loại log
        self.o_log.tag_configure("info", foreground="#64b5f6")
        self.o_log.tag_configure("success", foreground="#69f0ae")
        self.o_log.tag_configure("warning", foreground="#ffd740")
        self.o_log.tag_configure("error", foreground="#ff5252")
        self.o_log.tag_configure("header", foreground="#ce93d8",
                                 font=("Cascadia Code", 9, "bold"))
        self.o_log.tag_configure("timestamp", foreground="#616161")
        self.o_log.tag_configure("dim", foreground="#757575")

        # Log khởi động
        self.ghi_log("═" * 42, "dim")
        self.ghi_log("  ⚡ WinStall Installer - Sẵn sàng", "header")
        self.ghi_log("═" * 42, "dim")

    # ========================================================
    # 4.2: XỬ LÝ SỰ KIỆN (người dùng thao tác)
    # ========================================================

    def chon_danh_muc(self, ten):
        """Khi người dùng click vào 1 danh mục"""

        # Bỏ highlight danh mục cũ
        if self.danh_muc_hien_tai and self.danh_muc_hien_tai in self.nut_danh_muc:
            khung_cu, nhan_cu, so_cu = self.nut_danh_muc[self.danh_muc_hien_tai]
            khung_cu.configure(bg=MAU['nen_menu'])
            nhan_cu.configure(bg=MAU['nen_menu'], fg=MAU['chu'])
            so_cu.configure(bg=MAU['xanh_dam'])

        # Highlight danh mục mới
        self.danh_muc_hien_tai = ten
        khung, nhan, so = self.nut_danh_muc[ten]
        khung.configure(bg=MAU['do'])
        nhan.configure(bg=MAU['do'], fg="white")
        so.configure(bg=MAU['nen_toi'])

        # Cập nhật tiêu đề
        self.tieu_de_danh_muc.configure(text=ten)

        # Reset lựa chọn
        self.app_da_chon.clear()
        self.cap_nhat_nut_cai()

        # Hiện danh sách app
        self.hien_danh_sach_app(ten)

    def hien_danh_sach_app(self, ten_danh_muc):
        """Hiện các app trong danh mục đã chọn"""
        # Xóa danh sách cũ
        for w in self.khung_ds_app.winfo_children():
            w.destroy()
        self.widget_app.clear()
        self.bien_tick.clear()
        self.canvas_app.yview_moveto(0)  # Cuộn lên đầu

        # Tạo card cho từng app
        ds_app = DANH_MUC_APP[ten_danh_muc]
        for ten_app, winget_id in ds_app.items():
            self.tao_the_app(ten_app, winget_id)

        # Kiểm tra trạng thái cài đặt (chạy ngầm)
        threading.Thread(
            target=self.kiem_tra_trang_thai_cai,
            args=(ds_app,), daemon=True
        ).start()

    def tao_the_app(self, ten_app, winget_id):
        """Tạo 1 thẻ (card) cho 1 ứng dụng"""

        # --- Khung thẻ ---
        the = tk.Frame(
            self.khung_ds_app, bg=MAU['nen_the'],
            highlightbackground=MAU['vien'], highlightthickness=1
        )
        the.pack(fill=tk.X, padx=12, pady=4)

        khung_trong = tk.Frame(the, bg=MAU['nen_the'])
        khung_trong.pack(fill=tk.X, padx=12, pady=9)

        # --- Bên trái: checkbox + icon + tên ---
        ben_trai = tk.Frame(khung_trong, bg=MAU['nen_the'])
        ben_trai.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Checkbox
        bien_chon = tk.BooleanVar()
        tk.Checkbutton(
            ben_trai, variable=bien_chon, bg=MAU['nen_the'],
            selectcolor=MAU['nen_toi'], activebackground=MAU['nen_the'],
            command=lambda: self.xu_ly_tick(winget_id, bien_chon)
        ).pack(side=tk.LEFT, padx=(0, 8))

        # Icon
        nhan_icon = tk.Label(ben_trai, bg=MAU['nen_the'])
        nhan_icon.pack(side=tk.LEFT, padx=(0, 12))

        if CO_PILLOW:
            icon = self.lay_icon(winget_id, ten_app)
            if icon:
                nhan_icon.configure(image=icon)
                nhan_icon.image = icon
        else:
            nhan_icon.configure(
                text=ten_app[0], font=("Segoe UI", 16, "bold"),
                fg=MAU['do'], width=2
            )

        # Tên app và ID
        khung_ten = tk.Frame(ben_trai, bg=MAU['nen_the'])
        khung_ten.pack(side=tk.LEFT, fill=tk.X, expand=True)

        tk.Label(
            khung_ten, text=ten_app, font=("Segoe UI", 11, "bold"),
            bg=MAU['nen_the'], fg=MAU['chu_sang'], anchor=tk.W
        ).pack(anchor=tk.W)

        tk.Label(
            khung_ten, text=f"📦 {winget_id}", font=("Consolas", 8),
            bg=MAU['nen_the'], fg=MAU['chu_mo'], anchor=tk.W
        ).pack(anchor=tk.W)

        # --- Bên phải: trạng thái + nút cài ---
        ben_phai = tk.Frame(khung_trong, bg=MAU['nen_the'])
        ben_phai.pack(side=tk.RIGHT)

        nhan_trang_thai = tk.Label(
            ben_phai, text="⏳ Đang kiểm tra...",
            font=("Segoe UI", 8), bg=MAU['nen_the'], fg=MAU['chu_mo']
        )
        nhan_trang_thai.pack(anchor=tk.E)

        nhan_phien_ban = tk.Label(
            ben_phai, text="", font=("Segoe UI", 8),
            bg=MAU['nen_the'], fg=MAU['chu_mo']
        )
        nhan_phien_ban.pack(anchor=tk.E)

        nut_cai = tk.Button(
            ben_phai, text="📥 Cài đặt", font=("Segoe UI", 9, "bold"),
            bg=MAU['nut_cai'], fg="white", bd=0,
            padx=12, pady=4, cursor="hand2",
            command=lambda: self.cai_app(winget_id, ten_app)
        )
        nut_cai.pack(anchor=tk.E, pady=(4, 0))

        # Hover effect cho thẻ
        tat_ca_widget = [the, khung_trong, ben_trai, khung_ten, ben_phai]

        def khi_vao(e):
            the.configure(highlightbackground=MAU['do'])
            for w in tat_ca_widget:
                try:
                    w.configure(bg=MAU['nen_the_hover'])
                except Exception:
                    pass

        def khi_ra(e):
            the.configure(highlightbackground=MAU['vien'])
            for w in tat_ca_widget:
                try:
                    w.configure(bg=MAU['nen_the'])
                except Exception:
                    pass

        the.bind("<Enter>", khi_vao)
        the.bind("<Leave>", khi_ra)

        # Lưu widget để cập nhật sau
        self.widget_app[winget_id] = {
            'the': the,
            'trang_thai': nhan_trang_thai,
            'phien_ban': nhan_phien_ban,
            'nut': nut_cai,
            'ten': ten_app,
            'icon': nhan_icon,
        }
        self.bien_tick[winget_id] = bien_chon

    def lay_icon(self, winget_id, ten_app):
        """Lấy icon cho app. Ưu tiên file local → tải từ mạng → chữ cái"""
        key = winget_id

        # Đã có trong cache?
        if key in self.cache_icon:
            return self.cache_icon[key]

        # Có file local?
        ten_file = re.sub(r'[<>:"/\\|?*\s.]+', '_', ten_app).lower() + ".png"
        duong_dan = os.path.join(self.thu_muc_icon, ten_file)

        if os.path.isfile(duong_dan):
            try:
                anh = Image.open(duong_dan).convert('RGBA')
                anh = anh.resize((36, 36), Image.LANCZOS)
                photo = ImageTk.PhotoImage(anh)
                self.cache_icon[key] = photo
                return photo
            except Exception:
                pass

        # Tạo icon chữ cái làm placeholder
        chu_cai = ten_app[0] if ten_app else "?"
        icon = tao_icon_chu_cai(chu_cai, winget_id)
        self.cache_icon[key] = icon

        # Tải icon từ mạng (chạy ngầm)
        threading.Thread(
            target=self._tai_icon_ngam,
            args=(winget_id, ten_app, duong_dan),
            daemon=True
        ).start()

        return icon

    def _tai_icon_ngam(self, winget_id, ten_app, duong_dan):
        """Tải icon từ mạng và cập nhật giao diện"""
        du_lieu = tai_icon_tu_mang(winget_id, ten_app, self.thu_muc_icon)
        if not du_lieu:
            return

        try:
            anh = Image.open(io.BytesIO(du_lieu)).convert('RGBA')
            if anh.width < 16 or anh.height < 16:
                return

            # Lưu file
            anh_luu = anh.resize((128, 128), Image.LANCZOS)
            anh_luu.save(duong_dan, 'PNG')

            # Tạo ảnh hiển thị
            anh_hien = anh.resize((36, 36), Image.LANCZOS)
            photo = ImageTk.PhotoImage(anh_hien)
            self.cache_icon[winget_id] = photo

            # Cập nhật giao diện (phải chạy trên main thread)
            def cap_nhat():
                if winget_id in self.widget_app:
                    nhan = self.widget_app[winget_id].get('icon')
                    if nhan and nhan.winfo_exists():
                        nhan.configure(image=photo)
                        nhan.image = photo

            self.root.after(0, cap_nhat)
        except Exception:
            pass

    # ========================================================
    # 4.3: XỬ LÝ CHECKBOX
    # ========================================================

    def xu_ly_tick(self, winget_id, bien):
        """Khi tick/bỏ tick checkbox của 1 app"""
        if bien.get():
            self.app_da_chon.add(winget_id)
        else:
            self.app_da_chon.discard(winget_id)
        self.cap_nhat_nut_cai()

    def cap_nhat_nut_cai(self):
        """Cập nhật text và màu nút 'Cài đã chọn'"""
        so_chon = len(self.app_da_chon)
        self.nut_cai_chon.configure(
            text=f"📥 Cài đã chọn ({so_chon})",
            bg=MAU['do'] if so_chon > 0 else "#555"
        )

    def chon_tat_ca(self):
        """Tick tất cả app trong danh mục hiện tại"""
        if not self.danh_muc_hien_tai:
            return
        for wid, var in self.bien_tick.items():
            var.set(True)
            self.app_da_chon.add(wid)
        self.cap_nhat_nut_cai()

    def bo_chon_tat_ca(self):
        """Bỏ tick tất cả"""
        for var in self.bien_tick.values():
            var.set(False)
        self.app_da_chon.clear()
        self.cap_nhat_nut_cai()

    # ========================================================
    # 4.4: KIỂM TRA VÀ CÀI ĐẶT
    # ========================================================

    def kiem_tra_winget(self):
        """Kiểm tra xem máy có winget không (chạy ngầm)"""
        def chay():
            try:
                ket_qua = subprocess.run(
                    ["winget", "--version"],
                    capture_output=True, text=True, timeout=10,
                    encoding="utf-8", errors="ignore",
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                phien_ban = ket_qua.stdout.strip()
                self.root.after(0, lambda: self.nhan_trang_thai.configure(
                    text=f"✅ winget {phien_ban}", fg=MAU['xanh_la']
                ))
                self.ghi_log(f"✅ Đã tìm thấy winget {phien_ban}", "success")

            except FileNotFoundError:
                self.root.after(0, lambda: self.nhan_trang_thai.configure(
                    text="❌ Không có winget!", fg=MAU['do_loi']
                ))
                self.ghi_log("❌ winget chưa được cài!", "error")

            except Exception as loi:
                self.root.after(0, lambda: self.nhan_trang_thai.configure(
                    text=f"⚠️ {str(loi)[:25]}", fg=MAU['vang']
                ))

        threading.Thread(target=chay, daemon=True).start()

    def kiem_tra_trang_thai_cai(self, ds_app):
        """Kiểm tra từng app đã cài chưa (chạy ngầm)"""
        tong = len(ds_app)

        for i, (ten_app, winget_id) in enumerate(ds_app.items()):
            if winget_id not in self.widget_app:
                continue

            # Cập nhật tiến trình
            phan_tram = ((i + 1) / tong) * 100
            self.root.after(0, lambda p=phan_tram: self.bien_tien_trinh.set(p))
            self.root.after(0, lambda n=ten_app:
                self.nhan_tien_trinh.configure(text=f"Kiểm tra: {n}..."))

            try:
                ket_qua = subprocess.run(
                    ["winget", "list", "--id", winget_id,
                     "--accept-source-agreements"],
                    capture_output=True, text=True, timeout=15,
                    encoding="utf-8", errors="ignore",
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                output = ket_qua.stdout

                # Kiểm tra có trong danh sách đã cài không
                da_cai = (
                    winget_id.lower() in output.lower()
                    and "no installed" not in output.lower()
                )

                if da_cai:
                    phien_ban = self.tim_phien_ban(output, winget_id)
                    self.trang_thai_cai[winget_id] = True
                    self.root.after(0, lambda w=winget_id, v=phien_ban:
                        self.cap_nhat_trang_thai_the(w, True, v))
                else:
                    self.trang_thai_cai[winget_id] = False
                    self.root.after(0, lambda w=winget_id:
                        self.cap_nhat_trang_thai_the(w, False, None))

            except subprocess.TimeoutExpired:
                self.root.after(0, lambda w=winget_id:
                    self.cap_nhat_trang_thai_the(w, None, None, "⏱️ Quá giờ"))
            except Exception:
                self.root.after(0, lambda w=winget_id:
                    self.cap_nhat_trang_thai_the(w, None, None, "⚠️ Lỗi"))

        # Xong
        self.root.after(0, lambda: self.nhan_tien_trinh.configure(text="✅ Xong"))
        self.root.after(0, lambda: self.bien_tien_trinh.set(100))

    def tim_phien_ban(self, output, winget_id):
        """Tìm số phiên bản từ output của winget list"""
        for dong in output.strip().split('\n'):
            if winget_id.lower() in dong.lower():
                for tu in dong.split():
                    if re.match(r'^\d+[\.\d]+', tu):
                        return tu
        return "Đã cài"

    def cap_nhat_trang_thai_the(self, winget_id, da_cai, phien_ban, loi=None):
        """Cập nhật giao diện thẻ app sau khi kiểm tra"""
        if winget_id not in self.widget_app:
            return

        w = self.widget_app[winget_id]

        if loi:
            w['trang_thai'].configure(text=loi, fg=MAU['vang'])
            return

        if da_cai:
            w['trang_thai'].configure(text="✅ Đã cài đặt", fg=MAU['xanh_la'])
            if phien_ban:
                w['phien_ban'].configure(
                    text=f"📋 v{phien_ban}", fg=MAU['xanh_la']
                )
            w['nut'].configure(
                text="✅ Đã cài", bg=MAU['da_cai'], state=tk.NORMAL,
                command=lambda: self.hoi_cai_lai(winget_id, w['ten'])
            )
            w['the'].configure(highlightbackground=MAU['xanh_la'])
        else:
            w['trang_thai'].configure(text="⬜ Chưa cài", fg=MAU['chu_mo'])
            w['phien_ban'].configure(text="")
            w['nut'].configure(text="📥 Cài đặt", bg=MAU['nut_cai'])

    def hoi_cai_lai(self, winget_id, ten):
        """Hỏi người dùng có muốn cài lại không"""
        if messagebox.askyesno(
            "Đã cài đặt",
            f"'{ten}' đã được cài đặt.\nBạn muốn cài lại / cập nhật?"
        ):
            self.cai_app(winget_id, ten, buoc_cai=True)

    # ========================================================
    # 4.5: CÀI ĐẶT ỨNG DỤNG
    # ========================================================

    def cai_app(self, winget_id, ten_app, buoc_cai=False):
        """Cài 1 ứng dụng qua winget (chạy ngầm)"""

        # Kiểm tra đã cài chưa
        if not buoc_cai and self.trang_thai_cai.get(winget_id):
            self.ghi_log(f"⚠️ {ten_app} đã được cài đặt rồi", "warning")
            return

        self.ghi_log(f"📥 Đang cài: {ten_app}...", "info")

        # Đổi nút thành "Đang cài..."
        if winget_id in self.widget_app:
            self.widget_app[winget_id]['nut'].configure(
                text="⏳ Đang cài...", bg=MAU['vang'], state=tk.DISABLED
            )

        def chay():
            try:
                lenh = [
                    "winget", "install", "--id", winget_id,
                    "--accept-package-agreements",
                    "--accept-source-agreements"
                ]
                if buoc_cai:
                    lenh.append("--force")

                qua_trinh = subprocess.Popen(
                    lenh, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True, encoding="utf-8", errors="ignore",
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                stdout, stderr = qua_trinh.communicate(timeout=600)

                if qua_trinh.returncode == 0:
                    self.root.after(0, lambda:
                        self.ghi_log(f"✅ Cài thành công: {ten_app}", "success"))
                    self.trang_thai_cai[winget_id] = True
                    self.root.after(0, lambda:
                        self.cap_nhat_trang_thai_the(
                            winget_id, True, "Mới nhất"))

                elif "already installed" in (stdout + stderr).lower():
                    self.root.after(0, lambda:
                        self.ghi_log(f"⚠️ {ten_app} đã có sẵn", "warning"))
                    self.trang_thai_cai[winget_id] = True
                    self.root.after(0, lambda:
                        self.cap_nhat_trang_thai_the(
                            winget_id, True, "Đã cài"))

                else:
                    self.root.after(0, lambda:
                        self.ghi_log(f"❌ Lỗi khi cài: {ten_app}", "error"))
                    if winget_id in self.widget_app:
                        self.root.after(0, lambda:
                            self.widget_app[winget_id]['nut'].configure(
                                text="❌ Thử lại", bg=MAU['do_loi'],
                                state=tk.NORMAL
                            ))

            except subprocess.TimeoutExpired:
                qua_trinh.kill()
                self.root.after(0, lambda:
                    self.ghi_log(f"⏱️ Quá giờ: {ten_app}", "error"))

            except Exception as loi:
                self.root.after(0, lambda:
                    self.ghi_log(f"❌ Lỗi: {loi}", "error"))

        threading.Thread(target=chay, daemon=True).start()

    def cai_nhieu_app(self):
        """Cài tất cả app đã tick"""
        if not self.app_da_chon:
            messagebox.showinfo(
                "Thông báo",
                "Chưa chọn ứng dụng nào.\nHãy tick vào các ô bên trái."
            )
            return

        ds = list(self.app_da_chon)
        so_app = len(ds)

        if not messagebox.askyesno(
            "Xác nhận", f"Bạn muốn cài {so_app} ứng dụng?"
        ):
            return

        self.ghi_log(f"📦 Bắt đầu cài {so_app} ứng dụng...", "header")

        def chay():
            for i, wid in enumerate(ds):
                # Tìm tên app
                ten = wid
                for ds_app in DANH_MUC_APP.values():
                    for t, w in ds_app.items():
                        if w == wid:
                            ten = t
                            break

                # Cập nhật tiến trình
                self.root.after(0, lambda p=((i+1)/so_app)*100:
                    self.bien_tien_trinh.set(p))
                self.root.after(0, lambda n=ten, j=i+1:
                    self.nhan_tien_trinh.configure(
                        text=f"[{j}/{so_app}] {n}"))

                # Cài app
                self.root.after(0, lambda w=wid, n=ten:
                    self.cai_app(w, n))

                time.sleep(3)  # Chờ giữa các app

            self.root.after(0, lambda:
                self.ghi_log("✅ Hoàn tất cài hàng loạt!", "success"))
            self.root.after(0, lambda:
                self.nhan_tien_trinh.configure(text="✅ Xong!"))

        threading.Thread(target=chay, daemon=True).start()

    # ========================================================
    # 4.6: TÌM KIẾM
    # ========================================================

    def xu_ly_tim_kiem(self, *_):
        """Khi người dùng gõ vào ô tìm kiếm"""
        tu_khoa = self.bien_tim_kiem.get().lower().strip()

        # Nếu ô trống, hiện lại danh mục đang chọn
        if not tu_khoa:
            if self.danh_muc_hien_tai:
                self.hien_danh_sach_app(self.danh_muc_hien_tai)
            else:
                self.hien_man_chao()
            return

        # Xóa danh sách cũ
        for w in self.khung_ds_app.winfo_children():
            w.destroy()
        self.widget_app.clear()
        self.bien_tick.clear()
        self.tieu_de_danh_muc.configure(text=f"🔍 Tìm: '{tu_khoa}'")

        # Tìm app khớp
        tim_thay = {}
        for ds_app in DANH_MUC_APP.values():
            for ten, wid in ds_app.items():
                if tu_khoa in ten.lower() or tu_khoa in wid.lower():
                    self.tao_the_app(ten, wid)
                    tim_thay[ten] = wid

        if not tim_thay:
            tk.Label(
                self.khung_ds_app,
                text="😔 Không tìm thấy ứng dụng nào",
                font=("Segoe UI", 12),
                bg=MAU['nen_chinh'], fg=MAU['chu_mo']
            ).pack(pady=50)
        else:
            self.tieu_de_danh_muc.configure(
                text=f"🔍 '{tu_khoa}' ({len(tim_thay)} kết quả)")
            threading.Thread(
                target=self.kiem_tra_trang_thai_cai,
                args=(tim_thay,), daemon=True
            ).start()

    # ========================================================
    # 4.7: CÁC HÀM PHỤ TRỢ
    # ========================================================

    def lam_moi(self):
        """Làm mới danh sách app"""
        if self.danh_muc_hien_tai:
            self.ghi_log("🔄 Đang làm mới...", "info")
            self.trang_thai_cai.clear()
            self.hien_danh_sach_app(self.danh_muc_hien_tai)
        else:
            self.ghi_log("⚠️ Hãy chọn một danh mục trước.", "warning")

    def an_hien_log(self):
        """Ẩn/hiện phần log"""
        if self.log_dang_hien:
            self.khung_log.pack_forget()
            self.nut_an_log.configure(text="📋 Nhật ký ▲")
        else:
            self.khung_log.pack(fill=tk.X)
            self.nut_an_log.configure(text="📋 Nhật ký ▼")
        self.log_dang_hien = not self.log_dang_hien

    def xoa_log(self):
        """Xóa nội dung log"""
        self.o_log.configure(state=tk.NORMAL)
        self.o_log.delete(1.0, tk.END)
        self.ghi_log("🗑️ Đã xóa nhật ký.", "dim")

    def ghi_log(self, noi_dung, loai="info"):
        """Ghi 1 dòng vào log"""
        self.o_log.configure(state=tk.NORMAL)

        # Thêm thời gian (trừ dòng trang trí)
        if loai not in ("dim", "header"):
            gio = datetime.now().strftime("%H:%M:%S")
            self.o_log.insert(tk.END, f"[{gio}] ", "timestamp")

        self.o_log.insert(tk.END, f"{noi_dung}\n", loai)
        self.o_log.see(tk.END)
        self.o_log.configure(state=tk.DISABLED)


# ============================================================
# PHẦN 5: KHỞI CHẠY
# ============================================================

def main():
    root = tk.Tk()

    # Chỉnh DPI cho Windows
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    app = UngDungCaiDat(root)

    # Căn giữa cửa sổ
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (980 // 2)
    y = (root.winfo_screenheight() // 2) - (750 // 2)
    root.geometry(f"980x750+{x}+{y}")
    try:
        root.iconbitmap("install.ico")
    except Exception:
        pass
    root.mainloop()


if __name__ == "__main__":
    main()

    ''' # Dọn dẹp thư mục icon khi tắt
    if os.path.exists("images") and os.path.isdir("images"):
        try:
            shutil.rmtree("images", ignore_errors=True)
        except Exception:
            pass'''