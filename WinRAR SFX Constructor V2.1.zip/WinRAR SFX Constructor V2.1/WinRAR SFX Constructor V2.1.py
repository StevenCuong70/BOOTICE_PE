log_tmp = None  # Biến tạm để lưu thông báo lỗi nếu không tìm thấy thư viện icoextract
try:
    import ctypes
    import sys
    import time
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
    from tkinterdnd2 import DND_FILES, TkinterDnD
    from PIL import Image, ImageTk
    import subprocess, os, shutil, threading
    from icoextract import IconExtractor
except ImportError as e:
    pass
    log_tmp=e
# Tối ưu độ nét giao diện
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except:
    ctypes.windll.user32.SetProcessDPIAware()

def resource_path(file_path):
    """Hàm này giúp tìm đúng đường dẫn khi chạy dưới dạng .exe đã đóng gói bằng PyInstaller"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, file_path)


WINRAR_EXE = r"C:\Program Files\WinRAR\WinRAR.exe"
BASE_DIR = os.getcwd()
OUTPUT_DIR = os.path.join(BASE_DIR, r"Output_SFX")

class WinRAR_SFX_PackMode:
    def __init__(self, root):
        self.root = root
        self.root.title("WinRAR SFX Constructor V2.1 - Mạnh Cường Nguyễn")
        self.root.geometry("600x530")
        self.root.iconbitmap(resource_path("appicon.ico"))
        self.root.resizable(False, False)
        if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)
        # Variables
        
        self.src_path = tk.StringVar()
        self.exe_main = tk.StringVar()
        self.password = tk.StringVar()
        self.is_admin = tk.BooleanVar(value=False)
        self.is_autodelete = tk.BooleanVar(value=True)
        self.is_check_run = tk.BooleanVar(value=True)
        self.is_check_slient = tk.BooleanVar(value=False)
        self.is_solid = tk.BooleanVar(value=True)
        self.compression_level = tk.StringVar(value="5")
        self.custom_icon_path = tk.StringVar()
        self.photo_icon = None 

        self.setup_ui()

    def setup_ui(self):
        # --- PHẦN 1: NGUỒN & ICON ---
        f1 = tk.LabelFrame(self.root, text=" 1. Nguồn & Icon ", font=('Arial',9,'bold'), fg="#d64b20", padx=5, pady=5)
        f1.pack(fill="x", padx=5, pady=(0, 5))
        
        # Khung chứa Icon cố định kích thước
        self.icon_wrapper = tk.Frame(f1, width=80, height=80, bg="gray95", relief="groove", bd=1)
        self.icon_wrapper.pack(side="left", padx=5, pady=(0, 5))
        self.icon_wrapper.pack_propagate(False) 

        self.icon_box = tk.Label(self.icon_wrapper, text="No Icon", bg="gray95")
        self.icon_box.pack(expand=True, fill="both")
        self.icon_box.bind("<Button-1>", self.change_icon_manual)
        self.icon_box.config(cursor="hand2")

        # Khung bên phải chứa đường dẫn nguồn
        right_f1 = tk.Frame(f1)
        right_f1.pack(side="left", fill="x", expand=True)
        
        # --- Hàng 1: Đường dẫn nguồn ---
        tk.Label(right_f1, text="Đường dẫn nguồn (Kéo thả Folder vào đây)⬇️:", fg="#555555").pack(padx=5, pady=(5, 5), anchor="w")
        
        src_entry_row = tk.Frame(right_f1)
        src_entry_row.pack(fill="x", padx=5, pady=(0, 5))
        
        self.ent_src = tk.Entry(src_entry_row, textvariable=self.src_path, fg="#555555")
        self.ent_src.pack(side='left', expand=True, fill="x", padx=(0, 5))
        self.ent_src.config(cursor="arrow")  # Đổi con trỏ khi hover vào Entry
        
        btn_browse = tk.Button(src_entry_row, text="Chọn Input",relief="ridge",font=("Arial", 9, "bold"),width=10,background="#f18622",foreground="white", command=self.handle_drop_manual)
        btn_browse.pack(side="right", padx=(0, 5))
        btn_browse.config(cursor="hand2")

        # --- Hàng 2: Đường dẫn đầu ra ---
        tk.Label(right_f1, text="Thư mục lưu file SFX đầu ra ⏩:", fg="#555555").pack(anchor="w", pady=(0, 5))
        f_output = tk.Frame(right_f1)
        f_output.pack(fill="x", padx=5, pady=(0, 5))
        
        self.entry_path = tk.Entry(f_output,fg="#555555")
        self.entry_path.pack(side="left", expand=True, fill="x", padx=(0, 5))
        self.entry_path.insert(0, OUTPUT_DIR)
        
        btn_out = tk.Button(f_output, text="Chọn Output", relief="ridge",font=("Arial", 9, "bold"), width=10, background="#f18622", foreground="white", command=self.choose_folder)
        btn_out.pack(side="right",padx=(0, 5))
        btn_out.config(cursor="hand2")


        # --- PHẦN 2: CẤU HÌNH THỰC THI & BẢO MẬT ---
        f2 = tk.LabelFrame(self.root, text=" 2. Cấu hình thực thi & Bảo mật ", font=('Arial',9,'bold'), fg="#d64b20", padx=5, pady=5)
        f2.pack(fill="x", padx=10, pady=(5, 5))
        
        # Chia 2 cột bên trong f2
        col_left = tk.Frame(f2)
        col_left.pack(side="left", expand=True, fill="x", padx=(0, 5))
        label = tk.Label(col_left, text="Chọn file thực thi (.exe):", font=("segoe ui", 9,'bold'),foreground="#555555", anchor="w")
        label.pack(fill="x",pady=(0, 5))
        self.cb_exe = ttk.Combobox(col_left, textvariable=self.exe_main, state="readonly",width=35)
        self.cb_exe.pack(fill="x", pady=(5, 5))
        self.cb_exe.config(cursor="hand2")
        self.cb_exe.bind("<<ComboboxSelected>>", self.update_preview)

        col_right = tk.Frame(f2)
        col_right.pack(side="left", expand=True, fill="x", padx=(5, 0))
        label = tk.Label(col_right, text="Mật khẩu bảo vệ (Nếu có):", font=("segoe ui", 9,'bold'),foreground="#555555", anchor="w")
        label.pack(fill="x",padx=(35, 0),pady=(0, 5))
        self.entry_password = tk.Entry(col_right, textvariable=self.password, show="*",width=25)
        self.entry_password.pack(side="left", padx=(35,5),pady=(5, 5))

        self.btn_show_pass = tk.Button(col_right, text="Hiện mật khẩu",font=("Arial", 9, "bold"),width=12,command= self.show_password)
        self.btn_show_pass.pack(side="right", padx=(5, 0), pady=(5, 5))
        self.btn_show_pass.config(cursor="hand2")

        # --- PHẦN 3: TÙY CHỌN NÉN & OUTPUT ---
        f3 = tk.LabelFrame(self.root, text=" 3. Tùy chọn nén & Đường dẫn SFX ", font=('Arial',9,'bold'), fg="#d64b20", padx=5, pady=5)
        f3.pack(fill="x", padx=10, pady=5)

        # --- Phần trên: Checkbox + Combo ---
        f3_top = tk.Frame(f3)
        f3_top.pack(fill="x", pady=(0, 5))
        # Chia f3_top làm 2 cột
        col_left_f3 = tk.Frame(f3_top)
        col_left_f3.pack(side="left", expand=True, fill="both")
        
        col_right_f3 = tk.Frame(f3_top)
        col_right_f3.pack(side="right", fill="y")

        f4_top = tk.Frame(f3)
        f4_top.pack(fill="x", pady=(0, 5))
        col_left_f4 = tk.Frame(f4_top)
        col_left_f4.pack(side="left", expand=True, fill="both")
        
        col_right_f4 = tk.Frame(f4_top)
        col_right_f4.pack(side="right", fill="y")

        # --- NỘI DUNG CỘT TRÁI (4 Checkbuttons chia làm 2 hàng) ---
        # Hàng 1: 2 checkbuttons
        row_check_1 = tk.Frame(col_left_f3)
        row_check_1.pack(fill="x", pady=(0, 5))
        check1= tk.Checkbutton(row_check_1, text="Nén Solid archive (Nén tốt hơn).", variable=self.is_solid)
        check1.pack(side="left", anchor="w")
        check1.config(cursor="hand2")
        check2 = tk.Checkbutton(row_check_1, text="Yêu cầu Admin (UAC) khi chạy.", variable=self.is_admin)
        check2.pack(side="left", anchor="w", padx=(15, 0))
        check2.config(cursor="hand2")

        # Hàng 2: 2 checkbuttons
        row_check_2 = tk.Frame(col_left_f3)
        row_check_2.pack(fill="x")
        check3 = tk.Checkbutton(row_check_2, text="Xóa file tạm sau khi chạy (TEMP).", variable=self.is_autodelete)
        check3.pack(side="left", anchor="w")
        check3.config(cursor="hand2")
        self.check_run = tk.Checkbutton(row_check_2, text="Chạy file SFX sau khi tạo xong.", variable=self.is_check_run)
        self.check_run.pack(side="left", anchor="w", padx=(10, 0))
        self.check_run.config(cursor="hand2")

        row_check_3 = tk.Frame(col_left_f4)
        row_check_3.pack(fill="x")
        self.Check_Silient = tk.Checkbutton(row_check_3, text="Hiện Cửa sổ giải nén khi chạy SFX.", variable=self.is_check_slient)
        self.Check_Silient.pack(side="left", anchor="w", padx=(0, 5))
        self.Check_Silient.config(cursor="hand2")

        # --- NỘI DUNG CỘT PHẢI (Mức độ nén) ---
        lb = tk.Label(col_right_f3, text="Level nén SFX:", font=("segoe ui", 9),foreground="#555555", anchor="w")
        lb.pack(anchor="w",padx=(0,20))
        self.cb_level = ttk.Combobox(col_right_f3, values=["0", "1", "2", "3", "4", "5"], 
                                     textvariable=self.compression_level, width=10,font=("segoe ui", 10,'bold'), justify="center", state="readonly")
        self.cb_level.pack(anchor="w",padx=(0,20), pady=(5, 0))

       

        # --- PHẦN 4: TIẾN TRÌNH & THỰC THI ---
        f4 = tk.LabelFrame(self.root, text=" 4. Trạng thái hệ thống ", font=('Arial',9,'bold'), fg="#d64b20", padx=5, pady=5)
        f4.pack(fill="x", padx=10, pady=5)
        
        self.p_bar = ttk.Progressbar(f4, orient="horizontal", mode="determinate")
        self.p_bar.pack(fill="x")
        
        self.status = tk.Label(f4, text="Sẵn sàng...", fg="#1b4ae4", font=("Arial", 9, "italic"))
        self.status.pack(pady=(5, 0))
        if log_tmp:
            self.status.config(text=log_tmp, fg="red")

        # Nút Build lớn
        self.btn_go = tk.Button(self.root, text="BẮT ĐẦU ĐÓNG GÓI SFX ✨", bg="#2c3e50", fg="white", 
                                font=("Arial", 11, "bold"), height=1, command=self.start_thread)
        self.btn_go.pack(fill="x", padx=10, pady=10)

        # Đăng ký kéo thả cho toàn bộ root
        self.root.drop_target_register(DND_FILES)
        self.root.dnd_bind('<<Drop>>', self.handle_drop)

    # --- LOGIC XỬ LÝ ---
    def show_password(self):
        if self.entry_password.cget("show") == "*":
            self.entry_password.config(show="")
            self.btn_show_pass.config(text="Ẩn mật khẩu")
        else:
            self.entry_password.config(show="*")
            self.btn_show_pass.config(text="Hiện mật khẩu")

    def choose_folder(self):
        path = filedialog.askdirectory(title="Select a Folder",mustexist=True,parent=self.root)
        if path: 
            self.entry_path.delete(0, tk.END)
            # Insert the new filename at the beginning (0)
            self.entry_path.insert(0, path)

    def handle_drop(self, event):
        path = event.data.strip('{}').replace('"', '')
        self._load_path(path)

    def handle_drop_manual(self):
        path = filedialog.askdirectory()
        if path: self._load_path(path)

    def _load_path(self, path):
        if os.path.isdir(path):
            self.src_path.set(path)
            exes = [f for f in os.listdir(path) if f.lower().endswith(".exe")]
            self.cb_exe['values'] = exes
            if exes: 
                self.cb_exe.current(0)
                self.update_preview()
            else:
                self.cb_exe.set("")
                self.icon_box.config(image="", text="No Exe")
        elif path.lower().endswith(".exe"):
            self.src_path.set(os.path.dirname(path))
            self.cb_exe['values'] = [os.path.basename(path)]
            self.cb_exe.set(os.path.basename(path))
            self.update_preview()

    def update_preview(self, event=None):
        exe_path = os.path.join(self.src_path.get(), self.exe_main.get())
        if os.path.exists(exe_path):
            try:
                temp_ico = os.path.join(BASE_DIR, "tmp_preview.ico")
                ext = IconExtractor(exe_path)
                ext.export_icon(temp_ico)
                # Resize icon cho vừa khung 80x80 (đã trừ padding)
                img = Image.open(temp_ico).resize((64, 64), Image.Resampling.LANCZOS)
                self.photo_icon = ImageTk.PhotoImage(img)
                self.icon_box.config(image=self.photo_icon, text="")
                self.custom_icon_path.set(temp_ico)
            except:
                self.icon_box.config(image="", text="Error Icon")

    def change_icon_manual(self, event):
        path = filedialog.askopenfilename(filetypes=[("Icon files", "*.ico")])
        if path:
            img = Image.open(path).resize((64, 64), Image.Resampling.LANCZOS)
            self.photo_icon = ImageTk.PhotoImage(img)
            self.icon_box.config(image=self.photo_icon, text="")
            self.custom_icon_path.set(path)

    def start_thread(self):
        if not os.path.exists(WINRAR_EXE):
            messagebox.showerror("Lỗi chương trình!", f"- Không tìm thấy WinRAR.exe tại đường dẫn mặc định: {WINRAR_EXE}\n- Kiểm tra lại đường dẫn cài đặt WinRAR hoặc cài đặt WinRAR nếu chưa có.",icon="error")
            return
        threading.Thread(target=self.process_build, daemon=True).start()

    def process_build(self):
        src = self.src_path.get()
        run_exe = self.exe_main.get()
        OUT_PATH = self.entry_path.get()

        if not src or not run_exe:
            messagebox.showwarning("Thiếu dữ liệu", "Vui lòng chọn nguồn và file chạy chính của chương trình!")
            return

        self.btn_go.config(state="disabled")
        
        output_exe = os.path.join(OUT_PATH, os.path.basename(src) + "_SFX.exe")
        
        config_path = os.path.join(BASE_DIR, "config.txt")
        temp_dir = os.environ['TEMP']

        with open(config_path, "w", encoding="utf-16") as f: # WinRAR ưu tiên UTF-16 cho ký tự đặc biệt
            f.write("Title=Software SFX Build By [Manh Cuong Nguyen]\n")
            f.write("Text=Winrar SFX Constructor\n")
            # Ép WinRAR cập nhật file mà không hỏi han đường dẫn
            f.write("Update=U\n")
            # Ghi đè và chạy ẩn (Silent=1: Ẩn hoàn toàn, Silent=2: Hiện progress)
            f.write("Overwrite=1\n")
            # Path: Nơi giải nén. Dùng .\ nếu muốn giải nén tại chỗ
            f.write(f"Path={temp_dir}\n")

            if self.is_check_slient.get():
                f.write("Silent=2\n")
            else:
                f.write("Silent=1\n")

            # Chế độ TempMode: Giải nén vào thư mục tạm và XÓA sau khi chạy xong Setup
            if self.is_autodelete.get():
                f.write("TempMode\n")
            
            # Chạy file thực thi (bọc ngoặc kép để tránh lỗi khoảng trắng)
            f.write(f"Setup=\"{run_exe}\"\n")
            
           

        self.status.config(text="WinRAR đang build file SFX .EXE...", fg="orange")
        self.p_bar['value'] = 40
        #list command: https://winrar-france.fr/winrar_instructions_for_use/source/html/HELPSwitches.htm  https://documentation.help/WinRAR/HELPSwitches.htm
        cmd = [
                WINRAR_EXE, "a", "-sfx", "-y", "-ep1", "-r", "-ma5",
                    f"-m{self.compression_level.get()}",
                    "-md128", # Dictionary size 128MB giúp nén cực tốt cho App nặng
                    "-oc",    # Bỏ qua kiểm tra mã lỗi để build nhanh
                    "-scu",   # Ép dùng Unicode cho mọi bảng thông báo
                ]
        
        if self.is_solid.get(): cmd.append("-s")
        if self.is_admin.get(): cmd.append("-iadm")
        if self.password.get(): cmd.append(f"-hp{self.password.get()}")
        if self.custom_icon_path.get(): cmd.append(f"-iicon{self.custom_icon_path.get()}")
        
        cmd.append(f"-z{config_path}")
        cmd.append(output_exe)
        cmd.append(os.path.join(src, "*"))
        
        try:
            subprocess.run(cmd, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            self.p_bar['value'] = 100
            self.status.config(text="XONG! File đã sẵn sàng.", fg="green")
            if self.is_check_run.get():
                if self.is_admin.get():
                   ctypes.windll.shell32.ShellExecuteW(None, "runas", output_exe, None, None, 1) # Mở file với quyền admin
                    
                else:
                    subprocess.run([output_exe], check=True) # Mở file sau khi tạo xong)

        except Exception as e:
            messagebox.showerror("Lỗi", str(e))
        finally:
            self.btn_go.config(state="normal")
            if os.path.exists(config_path):
                os.remove(config_path)
            

if __name__ == "__main__":
    root = TkinterDnD.Tk()
    app = WinRAR_SFX_PackMode(root)
    root.mainloop()
