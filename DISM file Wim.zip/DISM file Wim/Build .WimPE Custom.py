import os
import sys
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import ctypes

def is_admin():
    try: return ctypes.windll.shell32.IsUserAnAdmin()
    except: return False
        
class WimCustomizerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("WinPE WIM Customizer - Công cụ Tùy biến WinPE")
        self.root.geometry("650x520")
        self.root.resizable(False, False)

        # Thiết lập theme cho giao diện sạch đẹp hơn
        style = ttk.Style()
        style.theme_use('clam')
        
        # Biến lưu trữ thông tin dữ liệu
        self.wim_path = tk.StringVar()
        self.mount_path = tk.StringVar(value="C:\\Mount_WIM")  # Mặc định thư mục Mount
        self.selected_index = tk.StringVar()
        
        # --- Bố cục Giao diện (UI Elements) ---
        
        # 1. Khung chọn file WIM
        lbl_wim = ttk.Label(root, text="Đường dẫn file .wim của WinPE:", font=("Segoe UI", 10, "bold"))
        lbl_wim.pack(anchor="w", padx=15, pady=(15, 2))
        
        wim_frame = ttk.Frame(root)
        wim_frame.pack(fill="x", padx=15, pady=2)
        txt_wim = ttk.Entry(wim_frame, textvariable=self.wim_path, font=("Segoe UI", 9))
        txt_wim.pack(side="left", fill="x", expand=True, padx=(0, 5))
        btn_wim = ttk.Button(wim_frame, text="Chọn File .WIM", command=self.browse_wim)
        btn_wim.pack(side="right")
        
        # 2. Khung chọn thư mục Mount
        lbl_mount = ttk.Label(root, text="Thư mục giải nén tạm thời (Mount Directory):", font=("Segoe UI", 10, "bold"))
        lbl_mount.pack(anchor="w", padx=15, pady=(10, 2))
        
        mount_frame = ttk.Frame(root)
        mount_frame.pack(fill="x", padx=15, pady=2)
        txt_mount = ttk.Entry(mount_frame, textvariable=self.mount_path, font=("Segoe UI", 9))
        txt_mount.pack(side="left", fill="x", expand=True, padx=(0, 5))
        btn_mount = ttk.Button(mount_frame, text="Chọn Thư Mục", command=self.browse_mount)
        btn_mount.pack(side="right")
        
        # 3. Khung cấu hình Index hình ảnh
        idx_frame = ttk.Frame(root)
        idx_frame.pack(fill="x", padx=15, pady=10)
        lbl_idx = ttk.Label(idx_frame, text="Chỉ số hệ điều hành (Index):", font=("Segoe UI", 9))
        lbl_idx.pack(side="left", padx=(0, 10))
        self.cb_index = ttk.Combobox(idx_frame, textvariable=self.selected_index, width=5, values=["1", "2"])
        self.cb_index.set("1")
        self.cb_index.pack(side="left")
        btn_check_idx = ttk.Button(idx_frame, text="Kiểm tra danh sách Index", command=self.check_wim_info)
        btn_check_idx.pack(side="left", padx=15)
        
        # 4. Khung chứa các nút điều khiển chức năng
        btn_frame = ttk.Labelframe(root, text=" Các chức năng thực thi ")
        btn_frame.pack(fill="x", padx=15, pady=15, ipadx=10, ipady=10)
        
        self.btn_mount_wim = ttk.Button(btn_frame, text="1. Mount (Gắn và Giải nén WIM)", command=self.mount_wim)
        self.btn_mount_wim.grid(row=0, column=0, padx=10, pady=5, sticky="ew")
        
        self.btn_open_dir = ttk.Button(btn_frame, text="2. Mở thư mục để thêm/bớt App", command=self.open_mount_dir, state="disabled")
        self.btn_open_dir.grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        
        self.btn_unmount_commit = ttk.Button(btn_frame, text="3. Lưu thay đổi & Đóng gói lại", command=lambda: self.unmount_wim(commit=True), state="disabled")
        self.btn_unmount_commit.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        
        self.btn_unmount_discard = ttk.Button(btn_frame, text="4. Hủy bỏ thay đổi & Tháo WIM", command=lambda: self.unmount_wim(commit=False), state="disabled")
        self.btn_unmount_discard.grid(row=1, column=1, padx=10, pady=5, sticky="ew")
        
        btn_frame.columnconfigure(0, weight=1)
        btn_frame.columnconfigure(1, weight=1)
        
        # 5. Khung hiển thị log tiến trình CMD DISM
        lbl_log = ttk.Label(root, text="Nhật ký tiến trình chạy lệnh hệ thống:", font=("Segoe UI", 9))
        lbl_log.pack(anchor="w", padx=15, pady=(5, 2))
        self.txt_log = tk.Text(root, height=8, width=70, state="disabled", wrap="word", bg="#1e1e1e", fg="#d4d4d4", font=("Consolas", 9))
        self.txt_log.pack(padx=15, pady=(0, 15), fill="both", expand=True)
        
        # Cấu hình màu sắc cho tag log (Xanh nhạt cho OK, Đỏ cho lỗi)
        self.txt_log.tag_config("ok", foreground="#4ec9b0")    # Xanh nhạt (Cyan)
        self.txt_log.tag_config("error", foreground="#f44747") # Đỏ sáng
        self.txt_log.tag_config("info", foreground="#d4d4d4")  # Xám sáng bình thường
        self.txt_log.tag_config("wait", foreground="#c7a20d")  # Vàng nhạt (Chờ)
        
    def log(self, message, level="info"):
        self.txt_log.config(state="normal")
        self.txt_log.insert(tk.END, "=> " +message + "\n", level)
        self.txt_log.see(tk.END)
        self.txt_log.config(state="disabled")
        self.root.update_idletasks()

    def browse_wim(self):
        file_path = filedialog.askopenfilename(filetypes=[("WIM files", "*.wim"), ("All files", "*.*")])
        if file_path:
            self.wim_path.set(file_path.replace("/", "\\"))
            self.log(f"Đã chọn file WIM: {file_path}", "ok")

    def browse_mount(self):
        # Mở hộp thoại chọn thư mục
        dir_path = filedialog.askdirectory(title="Chọn thư mục Mount WIM")
        
        # Nếu người dùng chọn thư mục và bấm OK
        if dir_path:
            self.mount_path.set(dir_path.replace("/", "\\"))
            self.log(f"Đã chọn thư mục Mount: {dir_path}", "ok")
        else:
            # Nếu người dùng bấm Cancel (dir_path rỗng), giữ nguyên hoặc gán lại C:\Mount_WIM
            self.mount_path.set("C:\\Mount_WIM")
            self.log("Người dùng hủy chọn thư mục. Sử dụng thư mục mặc định: C:\\Mount_WIM", "ok")

    def check_wim_info(self):
        wim = self.wim_path.get()
        if not wim or not os.path.exists(wim):
            self.log("Lỗi: Vui lòng chọn file .wim hợp lệ trước!", "error")
            messagebox.showerror("Lỗi", "Vui lòng chọn file .wim hợp lệ trước!")
            return
        
        self.log("Đang quét thông tin cấu trúc file WIM..","wait")
        cmd = f'dism /get-wiminfo /wimfile:"{wim}"'
        res = subprocess.run(cmd, capture_output=True, text=True, shell=True)
        
        indexes = []
        for line in res.stdout.splitlines():
            if "Index :" in line or "Chỉ số :" in line:
                idx = line.split(":")[-1].strip()
                indexes.append(idx)
        
        if indexes:
            self.cb_index['values'] = indexes
            self.cb_index.set(indexes[0])
            
        self.log(res.stdout, "ok")

    def mount_wim(self):
        wim = self.wim_path.get()
        mount = self.mount_path.get()
        idx = self.selected_index.get()
        
        if not wim or not mount or not idx:
            self.log("Lỗi: Vui lòng chọn đầy đủ file WIM, thư mục tạm và Index!", "error")
            messagebox.showerror("Lỗi", "Vui lòng chọn đầy đủ file WIM, thư mục tạm và Index!")
            return
            
        if not os.path.exists(mount):
            try:
                os.makedirs(mount)
            except Exception as e:
                self.log(f"Lỗi khởi tạo thư mục mount: {e}", "error")
                messagebox.showerror("Lỗi", f"Không thể khởi tạo thư mục mount: {e}")
                return

        self.log(f"Đang tiến hành Mount file WIM (Index {idx}) vào {mount} ","wait")
        cmd = f'dism /mount-wim /wimfile:"{wim}" /index:{idx} /mountdir:"{mount}"'
        
        res = subprocess.run(cmd, capture_output=True, text=True, shell=True)
        
        if res.returncode == 0:
            self.log(res.stdout, "ok")
            self.log("Đã Mount file WIM thành công!", "ok")
            messagebox.showinfo("Thành công", "Đã Mount file xong! Thư mục đã sẵn sàng để bạn tùy chỉnh App.")
            self.btn_open_dir.config(state="normal")
            self.btn_unmount_commit.config(state="normal")
            self.btn_unmount_discard.config(state="normal")
            self.btn_mount_wim.config(state="disabled")
        else:
            self.log(res.stdout, "info")
            self.log(res.stderr, "error")
            self.log("Mount thất bại!", "error")
            messagebox.showerror("Lỗi", "Mount thất bại! Vui lòng kiểm tra quyền Admin hoặc file WIM có đang bị ứng dụng khác khóa không.")

    def open_mount_dir(self):
        mount = self.mount_path.get()
        if os.path.exists(mount):
            os.startfile(mount)
            self.log(f"Đã mở thư mục: {mount}", "ok")
        else:
            self.log(f"Thư mục không tồn tại: {mount}", "error")

    def unmount_wim(self, commit=True):
        mount = self.mount_path.get()
        action = "/commit" if commit else "/discard"
        action_name = "LƯU THAY ĐỔI & ĐỒNG BỘ ĐÓNG GÓI" if commit else "HỦY BỎ TẤT CẢ THAY ĐỔI"
        
        if not mount:
            return
            
        if not messagebox.askyesno("Xác nhận hành động", f"Bạn có chắc chắn muốn tháo ổ và thực hiện: {action_name}?\n\n*LƯU Ý: Phải TẮT hoàn toàn tất cả cửa sổ File Explorer hoặc file/thư mục đang mở liên quan tới thư mục mount trước khi bấm Yes.*"):
            return
            
        self.log(f"Đang tháo Mount và tiến hành {action_name}.. Vui lòng đợi trong giây lát..", "wait")
        cmd = f'dism /unmount-wim /mountdir:"{mount}" {action}'
        
        res = subprocess.run(cmd, capture_output=True, text=True, shell=True)
        
        if res.returncode == 0:
            self.log(res.stdout, "ok")
            self.log("Quá trình tháo Mount và hoàn tất thành công!", "ok")
            messagebox.showinfo("Thành công", "Quá trình hoàn tất thành công!")
            self.btn_open_dir.config(state="disabled")
            self.btn_unmount_commit.config(state="disabled")
            self.btn_unmount_discard.config(state="disabled")
            self.btn_mount_wim.config(state="normal")
        else:
            self.log(res.stdout, "info")
            self.log(res.stderr, "error")
            self.log("Tháo mount (Unmount) thất bại!", "error")
            messagebox.showerror("Lỗi", "Tháo mount (Unmount) thất bại! Lỗi này thường do bạn vẫn đang mở thư mục mount hoặc có file ứng dụng bên trong chưa đóng.")
        #don dep thu muc mount sau khi unmount
        if os.path.exists(mount):
            try:
                os.rmdir(mount)
                self.log(f"Đã xóa thư mục Mount: {mount}", "ok")
            except Exception as e:
                self.log(f"Không thể xóa thư mục Mount: {e}", "error")
 
if __name__ == "__main__":
    if not is_admin(): 
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{sys.argv[0]}"', None, 1)
    else: 
        root = tk.Tk()
        app = WimCustomizerApp(root)
        root.mainloop()