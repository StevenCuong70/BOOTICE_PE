import ctypes
import sys
import time
import tkinter as tk
from tkinter import ttk, messagebox
import requests
from tkinterdnd2 import DND_FILES, TkinterDnD
from PIL import Image, ImageTk
import subprocess, os, shutil, threading
from icoextract import IconExtractor


try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1) # Chế độ nét căng trên Win 8/10/11
except:
    ctypes.windll.user32.SetProcessDPIAware() # Chế độ cũ cho Win 7

def resource_path(file_path):
    """Hàm này giúp tìm đúng đường dẫn khi chạy dưới dạng .exe đã đóng gói bằng PyInstaller"""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, file_path)

# CẤU HÌNH ĐƯỜNG DẪN
#cấu hình lại BASE_DIR để luôn trỏ về thư mục chứa script, tránh lỗi khi chạy dưới dạng .exe đã đóng gói

BASE_DIR =  os.getcwd()
folder_extension= os.path.abspath("Extension")
SEVEN_ZIP_EXE = os.path.join(folder_extension, r"7z.exe")
SEVEN_ZIP_DLL = os.path.join(folder_extension, r"7z.dll")
SFX_MODULE_asInvoker = os.path.join(folder_extension, r"7zSD_asInvoker.sfx")
SFX_MODULE_7zSD_requireAdministrator = os.path.join(folder_extension, r"7zSD_requireAdministrator.sfx")
RES_HACKER_EXE = os.path.join(folder_extension, r"ResourceHacker.exe")
CONFIG_FILE = os.path.join(BASE_DIR, r"config.txt")
OUTPUT_DIR = os.path.join(BASE_DIR, r"Output")

class SFXProUnified:
    def __init__(self, root):
        self.root = root
        self.root.title("7z SFX Builder By Mạnh Cường Nguyễn. V2.0 - Updated 2026-03-18")
        self.root.geometry("620x515")
        #self.root.configure(bg="#dcdad5")
        self.root.iconbitmap(resource_path("appicon.ico"))
        self.root.resizable(False, False)

        
        if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)
        
        # Khai báo biến
        self.src_path = tk.StringVar()
        self.exe_main = tk.StringVar()
        self.is_admin = tk.BooleanVar(value=True)
        self.is_autodelete = tk.BooleanVar(value=True)
        self.run_after_build = tk.BooleanVar(value=True)
        self.photo = None # Giữ reference cho ảnh

        self.setup_ui()

    def setup_ui(self):
        # --- PHẦN 1: NGUỒN VÀ ICON ---
        f1 = tk.LabelFrame(self.root, text=" 1. Nguồn ứng dụng & Preview icon. ",font=('Arial',9,'bold'),fg="#d64b20", padx=5, pady=5)
        f1.pack(fill="x", padx=15, pady=5)
        
        # Icon Box (Bên trái)
        self.icon_wrapper = tk.Frame(f1, width=80, height=80, bg="gray90", relief="groove", bd=1)
        self.icon_wrapper.pack(side="left", padx=(0, 15))
        self.icon_wrapper.pack_propagate(False) # Giữ khung không bị co lại theo ảnh

        self.icon_box = tk.Label(self.icon_wrapper, text="No Icon", bg="gray90")
        self.icon_box.pack(expand=True, fill="both")
        self.icon_box.bind("<Button-1>", self.change_icon) # Click vào để chọn icon thủ công
        self.icon_box.config(cursor='hand2')
        self.tooltip(self.icon_box, "Nhấn vào đây để chọn file icon (.ico) thủ công.\nNếu không chọn, icon sẽ được trích xuất tự động từ file .exe")
        
        # Cột bên phải của f1
        right_f1 = tk.Frame(f1)
        right_f1.pack(side="left", fill="both", expand=True)
        
        tk.Label(right_f1, text="Kéo & Thả Folder/File .exe vào đây ⬇︎:", fg="blue", font=("Arial", 9)).pack(anchor="w")
        self.ent_src = tk.Entry(right_f1, textvariable=self.src_path)
        self.ent_src.pack(fill="x", pady=5)
        #self.ent_src.config(state="readonly", cursor='arrow')
        self.tooltip(self.ent_src, "Kéo và thả folder chứa bộ cài hoặc file .exe chính vào đây.\nNếu bạn thả một folder, hãy chắc chắn rằng nó chứa file .exe cần chạy.")
        
        # Đăng ký kéo thả cho Entry
        self.ent_src.drop_target_register(DND_FILES)
        self.ent_src.dnd_bind('<<Drop>>', self.handle_drop)
        
        tk.Label(right_f1, text="⚡Gợi ý: kéo Thả folder chứa bộ cài của bạn vào đây ⬆.", fg="gray").pack(anchor="w")

        # --- PHẦN 2: CẤU HÌNH ---
        f2 = tk.LabelFrame(self.root, text=" 2. Cấu hình thực thi. ",font=('Arial',9,'bold'),fg="#d64b20", padx=5, pady=5)
        f2.pack(fill="x", padx=15, pady=5)
        
        tk.Label(f2, text="Chọn File chạy:",font=("Arial", 9),fg="#1b4ae4").pack(side='left',padx=(10,10),pady=5)
        self.cb_exe = ttk.Combobox(f2, textvariable=self.exe_main, state="readonly",width=40)
        self.cb_exe.pack(side='left',padx=5, pady=5)
        self.cb_exe.bind("<<ComboboxSelected>>", self.update_preview)
        self.cb_exe.config(cursor='hand2')
        self.tooltip(self.cb_exe, "Chọn file .exe chính sẽ được chạy sau khi giải nén xong.\nNếu bạn chọn một folder chứa nhiều file .exe, hãy chắc chắn chọn đúng file cần chạy.")

        self.btn_edit_cfg = tk.Button(f2, text="Chỉnh sửa Script 📄",width=16, fg="#3858e4",font=("Arial",9), command=self.open_cfg_file)
        self.btn_edit_cfg.pack(side='right',padx=(10,5), pady=(5,10))
        self.btn_edit_cfg.config(cursor='hand2')
        self.tooltip(self.btn_edit_cfg, "Mở file cấu hình để chỉnh sửa nội dung script bên trong file SFX.\nBạn có thể thay đổi tiêu đề, chế độ GUI, chương trình chạy sau khi giải nén, v.v...")

        # --- PHẦN 3: TÙY CHỌN ---
        f3 = tk.LabelFrame(self.root, text=" 3. Tùy chọn Build. ",font=('Arial',9,'bold'),fg="#d64b20", padx=5, pady=5)
        f3.pack(fill="x", padx=15, pady=5)
        
        self.check_UAC = tk.Checkbutton(f3, text="Yêu cầu Administrator (UAC).", variable=self.is_admin, font=("Arial", 9))
        self.check_UAC.pack(side="left", padx=10)
        self.check_UAC.config(cursor='hand2')
        self.tooltip(self.check_UAC, "Nếu chọn, file SFX sẽ yêu cầu quyền Administrator sau khi build.")

        self.check_delete = tk.Checkbutton(f3, text="Tự động Xóa file tạm.", variable=self.is_autodelete)
        self.check_delete.pack(side="left", padx=10)
        self.check_delete.config(cursor='hand2')
        self.tooltip(self.check_delete, "Nếu chọn, các file tạm sẽ được xóa sau khi quá trình build hoàn tất.")

        self.check_runApp = tk.Checkbutton(f3, text="Tự động chạy file EXE.", variable=self.run_after_build)
        self.check_runApp.pack(side="left", padx=10)
        self.check_runApp.config(cursor='hand2')
        self.tooltip(self.check_runApp, "Nếu chọn, file SFX sẽ tự động chạy sau khi được tạo thành công.")
        
        f31 = tk.LabelFrame(self.root, text=" 4. Cấu hình nén SFX. ",font=('Arial',9,'bold'),fg="#d64b20", padx=5, pady=5)
        f31.pack(fill="x", padx=15, pady=10)

        label_method = tk.Label(f31, text="Level nén:", font=("Arial", 9),fg="#1b4ae4")
        label_method.pack(side="left", padx=(70,10), pady=5)

        self.combo_level = ttk.Combobox(f31, values=[1,3,5,7,9],justify="center",font=("Arial", 9,'bold'),width=6, state="readonly")
        self.combo_level.pack(side="left", padx=(5,0),pady=5)
        self.combo_level.config(cursor='hand2')
        self.combo_level.current(2) 
        
        label_method = tk.Label(f31, text="Method nén:", font=("Arial", 9),fg="#1b4ae4")
        label_method.pack(side="left", padx=(100,0), pady=5)
        self.combo_method = ttk.Combobox(f31, values=["LZMA2", "LZMA"],justify="center",width=12,font=("Arial", 9,'bold'), state="readonly")
        self.combo_method.pack(side="right", padx=(10,80),pady=5)
        self.combo_method.config(cursor='hand2')
        self.combo_method.current(0) 
        self.tooltip(self.combo_level, "Level 1: (Nén nhanh nhất - giải nén nhanh,file build dung lượng lớn).\nLevel 9: (nén chậm nhất - giải nén chậm, file build dung lượng nhỏ nhất).\nMặc định Level 5 là trung bình.")
        self.tooltip(self.combo_method, "LZMA2 thường cho tỷ lệ nén tốt hơn nhưng có thể chậm hơn\nLZMA nhanh hơn nhưng file có thể lớn hơn. Mặc định là LZMA2.")

        # --- TIẾN TRÌNH ---
        f4 = tk.LabelFrame(self.root, text=" 5. Tiến trình build SFX. ", font=('Arial', 9, 'bold'), fg="#d64b20", padx=5, pady=5)
        f4.pack(fill="x", padx=15, pady=(5,5))
        
        # Container cho progress bar và label phần trăm
        p_frame = tk.Frame(f4)
        p_frame.pack(fill="x", padx=30, pady=(5, 5))
        
        self.p_bar = ttk.Progressbar(p_frame, orient="horizontal", mode="determinate", length=480)
        self.p_bar.pack(side="left", fill="x",padx=(0, 5))
        
        self.p_label = tk.Label(p_frame, text="0%", font=("Arial", 9, "bold"), width=5)
        self.p_label.pack(side="right", padx=(5, 0))
        
        self.status = tk.Label(f4, text="Chương trình Sẵn sàng...", fg="#1b4ae4", font=("Arial", 10))
        self.status.pack(pady=(5,0),fill="x",expand=True)

        # --- NÚT START ---
        self.btn_go = tk.Button(f4, text="BẮT ĐẦU TẠO SFX (.EXE) ✨", bg="#2ecc71", fg="white", 
                                font=("Arial", 11, "bold"), height=1, command=self.start_thread)
        self.btn_go.pack(fill="x", padx=5, pady=10)
        self.btn_go.config(cursor='hand2')
        self.tooltip(self.btn_go, "Nhấn vào đây để bắt đầu quá trình tạo file SFX.")

    def tooltip(self, widget, text):
        tooltip_window = [None]  # Dùng list để giữ reference trong closure
        
        def show_tooltip(event):
            if tooltip_window[0] is not None:
                return
            tooltip_window[0] = tk.Toplevel(widget)
            tooltip_window[0].wm_overrideredirect(True)
            tooltip_window[0].wm_geometry(f"+{event.x_root + 10}+{event.y_root + 10}")
            label = tk.Label(tooltip_window[0], text=text, background="#fffacd", foreground="#2c2c2c", 
                             relief="solid", borderwidth=1, font=("Arial", 8,'italic'), justify="left", padx=8, pady=4)
            label.pack()
        
        def hide_tooltip(event):
            if tooltip_window[0] is not None:
                tooltip_window[0].destroy()
                tooltip_window[0] = None
        
        widget.bind("<Enter>", show_tooltip)
        widget.bind("<Leave>", hide_tooltip)

   


    def change_icon(self, event):
        # Cho phép người dùng chọn file .ico thủ công nếu muốn
        from tkinter import filedialog
        temp_folder = os.path.join(BASE_DIR, "temp")
        temp_view_ico = os.path.join(temp_folder, "temp_view.ico")
        ico_path = filedialog.askopenfilename(title="Chọn file Icon (.ico)", filetypes=[("ICO files", "*.ico")])
        if ico_path:
            try:
                with Image.open(ico_path) as img:
                    img_res = img.resize((64, 64), Image.Resampling.LANCZOS)
                    self.photo = ImageTk.PhotoImage(img_res)
                self.icon_box.config(image=self.photo, text="")
                
                if not os.path.exists(temp_folder): 
                    os.makedirs(temp_folder)
                
                shutil.copy2(ico_path, temp_view_ico) # Lưu tạm file icon do người dùng chọn để dùng trong quá trình build
            except OSError as e:
                messagebox.showerror("Lỗi", f"Không thể mở file icon:\n{e}")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể mở file icon:\n{e}")

    def handle_drop(self, event):
        path = event.data.strip('{}').replace('"', '')
        
        if os.path.isdir(path):
            self.src_path.set(path)
            exes = [f for f in os.listdir(path) if f.lower().endswith(".exe")]
            self.cb_exe['values'] = exes
            if exes:
                self.cb_exe.current(0)
                self.update_preview()
            else:
                self.cb_exe.set("") # Xóa trắng nếu không có exe
                self.icon_box.config(image="", text="No Exe Found")
         
        elif path.lower().endswith(".exe"):
            folder = os.path.dirname(path)
            self.src_path.set(folder)
            exes = [f for f in os.listdir(folder) if f.lower().endswith(".exe")]
            self.cb_exe['values'] = exes
            self.cb_exe.set(os.path.basename(path))
            self.update_preview()

    def smooth_progress(self, target, duration=1.0):
        """Nhích từng % một cách từ từ để tạo cảm giác app đang chạy liên tục"""
        start = self.p_bar['value']
        step = (target - start) / 50 if target > start else 0
        for _ in range(50):
            if self.p_bar['value'] < target:
                self.p_bar['value'] += step
                self.p_label.config(text=f"{int(self.p_bar['value'])}%")
                self.root.update_idletasks()
                time.sleep(duration / 50)

    def animate_progress(self, target_value, speed=0.01):
        """Hàm giúp thanh progress chạy từ giá trị hiện tại đến target_value"""
        current_value = self.p_bar['value']
        while current_value < target_value:
            current_value += 1
            self.p_bar['value'] = current_value
            self.p_label.config(text=f"{int(current_value)}%")
            self.root.update_idletasks() # Cập nhật giao diện ngay lập tức
            time.sleep(speed) # Tốc độ chạy (càng nhỏ càng nhanh)

    def update_preview(self, event=None):
        t_ico = os.path.join(BASE_DIR, "tmp_view.ico")
        try:
            folder = self.src_path.get().strip('{}').replace('"', '')
            exe_file = self.exe_main.get()
            if not folder or not exe_file: return
            
            exe_full = os.path.join(folder, exe_file)
            if not os.path.exists(exe_full): return

            # Trích xuất icon
            extractor = IconExtractor(exe_full)
            extractor.export_icon(t_ico) # Trích xuất gốc (thường chứa đủ 16x16...256x256)
            
            with Image.open(t_ico) as img:
                # Nếu file ico có nhiều size, chọn size lớn nhất để resize cho nét
                # Thông thường img.size sẽ là size mặc định, nhưng ta có thể ép PIL chọn frame tốt hơn
                img_res = img.resize((64, 64), Image.Resampling.LANCZOS)
                self.photo = ImageTk.PhotoImage(img_res)
            
            self.icon_box.config(image=self.photo, text="")
        except:
            self.icon_box.config(image="", text="No Icon")
        finally:
            if os.path.exists(t_ico):
                try: os.remove(t_ico)
                except: pass

    def open_cfg_file(self):
        file_name = self.cb_exe.get()
        if not file_name:
            file_name = "setup.exe"
        try:
            # 1. Nếu file chưa tồn tại hoặc bị trống, tạo nội dung mẫu chuẩn
            if not os.path.exists(CONFIG_FILE) or os.path.getsize(CONFIG_FILE) == 0:
                default_content = (
                    ';!@Install@!UTF-8!\n'
                    'Title="SFX Installer"\n'
                    'GUIMode="1"\n'
                    'AutoInstall="1"\n'
                    'ExtractTitle="Please wait..."\n'
                    f'RunProgram="{file_name}"\n'
                    ';!@InstallEnd@!'
                )
                with open(CONFIG_FILE, "w", encoding="utf-8-sig") as f:
                    f.write(default_content)
            
            # 2. Mở file bằng ứng dụng mặc định của hệ thống (thường là Notepad)
            os.startfile(CONFIG_FILE)
            
        except OSError as e:
            messagebox.showerror("Lỗi", f"Không thể mở file cấu hình: {e}")
        except Exception as e:
            messagebox.showerror("Lỗi không xác định", str(e))

    def start_thread(self):
        threading.Thread(target=self.process_build, daemon=True).start()

    def animate_progress(self, target_value, speed=0.005):
        """Hỗ trợ chạy thanh progress mượt mà từ giá trị hiện tại đến target"""
        current_value = self.p_bar['value']
        # Nếu target nhỏ hơn current (reset), gán trực tiếp
        if target_value < current_value:
            self.p_bar['value'] = target_value
            self.p_label.config(text=f"{int(target_value)}%")
            return

        while current_value < target_value:
            current_value += 1
            if current_value > 100: current_value = 100
            self.p_bar['value'] = current_value
            self.p_label.config(text=f"{int(current_value)}%")
            self.root.update_idletasks()
            time.sleep(speed)

    def process_build(self):
        src, run = self.src_path.get(), self.exe_main.get()
        if not src or not run: 
            return messagebox.showerror("Lỗi!", "Vui lòng chọn nguồn và file chạy!")

        final_exe = os.path.join(OUTPUT_DIR, os.path.basename(src) + "_SFX.exe")
        temp_folder = os.path.join(BASE_DIR, "temp")
        if not os.path.exists(temp_folder): 
            os.makedirs(temp_folder)
        t_7z = os.path.join(temp_folder, "data.7z")
        tmp_cfg = os.path.join(temp_folder, "tmp_config.txt")
        t_exe = os.path.join(temp_folder, "tmp_build.exe")
        ico_p = os.path.join(temp_folder, "tmp.ico")
        temp_view_ico = os.path.join(temp_folder, "temp_view.ico") # File tạm chứa icon preview (nếu người dùng chọn thủ công)

        try:
            self.btn_go.config(state="disabled")
            self.ent_src.config(state="disabled")
            self.cb_exe.config(state="disabled")
            self.btn_edit_cfg.config(state="disabled")
            self.p_bar['value'] = 0
            
            # --- GIAI ĐOẠN 1: KHỞI ĐỘNG (1-10%) ---
            self.status.config(text="Đang khởi tạo tiến trình...", fg="#1b4ae4")
            self.smooth_progress(10, duration=0.5)

            # --- GIAI ĐOẠN 2: NÉN (10-60%) ---
            self.status.config(text="Đang nén dữ liệu (Vui lòng chờ...)", fg="#1b4ae4")
            # Chạy nén trong khi nhích nhẹ progress để người dùng biết app ko treo
            def run_7z():
                Method = self.combo_method.get()
                Level = self.combo_level.get()
                # -m0=Method: LZMA2 sẽ nén tốt hơn nhưng chậm hơn, Deflate nhanh hơn nhưng file có thể lớn hơn. Ta chọn tự động dựa trên kích thước nguồn.
                subprocess.run([SEVEN_ZIP_EXE, "a", "-y", 
                                f"-m0={Method}", f"-mx={Level}",
                                t_7z, os.path.join(src, "*")], 
                               check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            
            compress_thread = threading.Thread(target=run_7z)
            compress_thread.start()
            
            # Trong khi chờ nén, cho progress chạy từ 10% đến 60% thật chậm
            while compress_thread.is_alive():
                if self.p_bar['value'] < 60:
                    self.p_bar['value'] += 0.5
                    self.p_label.config(text=f"{int(self.p_bar['value'])}%")
                    self.root.update_idletasks()
                time.sleep(0.1)
            
            compress_thread.join()
            self.smooth_progress(65, duration=0.3)

            # --- GIAI ĐOẠN 3: CONFIG & GỘP (65-85%) ---
            self.status.config(text="Đang xử lý cấu hình và gộp file...", fg="#1b4ae4")
            
            # Viết config
            if not os.path.exists(CONFIG_FILE):
                default_content = (
                    ';!@Install@!UTF-8!\n'
                    'Title="SFX Installer"\n'
                    'GUIMode="1"\n'
                    'AutoInstall="1"\n'
                    'ExtractTitle="Please wait..."\n'
                    f'RunProgram="{run}"\n'
                    ';!@InstallEnd@!'
                )
                with open(CONFIG_FILE, "w", encoding="utf-8-sig") as f:
                    f.write(default_content)

            with open(CONFIG_FILE, "r", encoding="utf-8-sig") as f: lines = f.readlines()
            with open(tmp_cfg, "w", encoding="utf-8-sig") as f:
                for line in lines:
                    skip_keywords = ['RunProgram=', 'GUIMode=', 'AutoInstall=', 'MiscFlags=', 'ExtractTitle=']
                    if any(key in line for key in skip_keywords): continue
                    if ";!@InstallEnd@!" in line:
                        f.write('GUIMode="1"\nAutoInstall="1"\nExtractTitle="Please wait..."\n')
                        f.write(f'RunProgram="{run}"\n{line}')
                        if self.is_admin.get():
                            f.write('MiscFlags="4"\n') # 4 = Run with UAC
                        if self.is_autodelete.get():
                            f.write('Delete="%%T"\n')
                    else: f.write(line)
            
            # Gộp binary
            if self.is_admin.get():
                SFX_MODULE = SFX_MODULE_7zSD_requireAdministrator
            else:
                SFX_MODULE = SFX_MODULE_asInvoker
            with open(t_exe, "wb") as f_out:
                for p in [SFX_MODULE, tmp_cfg, t_7z]:
                    with open(p, "rb") as f_in: shutil.copyfileobj(f_in, f_out)
            
            self.smooth_progress(85, duration=0.5)

            # --- GIAI ĐOẠN 4: ICON & FINISH (85-100%) ---
            self.status.config(text="Đang chèn Icon vào file SFX...", fg="#1b4ae4")
            try:
                # Kiểm tra nếu người dùng đã thay đổi icon thủ công
                if os.path.exists(temp_view_ico):
                    # Dùng icon do người dùng tự chọn
                    icon_data = temp_view_ico
                else:
                    # Nếu không, trích xuất icon từ file .exe gốc
                    IconExtractor(os.path.join(src, run)).export_icon(ico_p)
                    icon_data = ico_p
                
                subprocess.run([RES_HACKER_EXE, "-open", t_exe, "-save", final_exe, "-action", "addoverwrite", 
                                "-res", icon_data, "-mask", "ICONGROUP,1,"], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            except:
                shutil.copy2(t_exe, final_exe)
            
            self.smooth_progress(100, duration=0.5)
            #dọn dẹp thư mục temp sau khi build xong
            subprocess.run(["cmd", "/c", "rmdir", "/s", "/q", os.getenv("temp")], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            self.status.config(text="TẠO SFX THÀNH CÔNG!", fg="green")

            # Dọn dẹp
            for f in [t_7z, t_exe, tmp_cfg, ico_p, temp_view_ico]:
                if os.path.exists(f): os.remove(f)
                
            if self.run_after_build.get():
                if self.is_admin.get():
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", os.path.abspath(final_exe), None, None, 1)
                    #dọn dẹp thư mục temp sau khi Chạy xong
                    subprocess.run(["cmd", "/c", "rmdir", "/s", "/q", os.getenv("temp")], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
                else:
                    subprocess.Popen(final_exe)
                    #dọn dẹp thư mục temp sau khi Chạy xong
                    subprocess.run(["cmd", "/c", "rmdir", "/s", "/q", os.getenv("temp")], check=True, creationflags=subprocess.CREATE_NO_WINDOW)

        except Exception as e:
            self.status.config(text="Xảy ra lỗi trong khi Build!", fg="red")
            messagebox.showerror("Error", str(e))
        finally:
            self.btn_go.config(state="normal")
            self.ent_src.config(state="normal")
            self.cb_exe.config(state="readonly")
            self.btn_edit_cfg.config(state="normal")
            if os.path.exists(temp_folder): 
                shutil.rmtree(temp_folder)
            

    def check_files(self):
        missing_files = []
        # Dọn file tạm cũ nếu có để tránh xung đột khi build
        for f in ["tmp_build.exe", "data.7z", "tmp_config.txt", "tmp.ico", "tmp_view.ico"]:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except Exception:
                pass  # tránh crash nếu file đang bị lock

        required_files = [RES_HACKER_EXE, SEVEN_ZIP_EXE, SEVEN_ZIP_DLL, SFX_MODULE_asInvoker, SFX_MODULE_7zSD_requireAdministrator]
        for item in required_files:
            if not os.path.exists(item):
                missing_files.append(item)

        if missing_files:
            self.status.config(text=f"Thiếu {len(missing_files)} file cần thiết!",fg="red")
            self.btn_go.config(state="disabled")
            result =  messagebox.askyesno("Thiếu file thực thi cần thiết!",
                "Có một số file cần thiết đang bị thiếu.\nBạn có muốn tự động tải về không?",
                icon="warning")
            if result:
                self.download_files()
                # Sau download kiểm tra lại
                for item in required_files:
                    if not os.path.exists(item):
                        return False
                self.btn_go.config(state="normal")
                return True
            return False
        return True
    
    
    def download_files(self):
        # Hàm này có thể được gọi khi phát hiện thiếu file để tự động tải về
        urls = {
            "7z.exe": "https://github.com/ollm/7zip-bin-full/raw/main/win/x64/7z.exe",
            "7z.dll": "https://github.com/ollm/7zip-bin-full/raw/main/win/x64/7z.dll",
            "7zSD_asInvoker.sfx": "https://gitlab.com/lord_mulder/7zSD-SFX-Mod/-/raw/master/bin/7zSD_asInvoker.sfx?inline=false",
            "7zSD_requireAdministrator.sfx": "https://gitlab.com/lord_mulder/7zSD-SFX-Mod/-/raw/master/bin/7zSD_requireAdministrator.sfx?inline=false",
            "ResourceHacker.exe": "https://github.com/Seabreg/resource_hacker/raw/master/ResourceHacker.exe"
        }
        for name, url in urls.items():
            if not os.path.exists(folder_extension):
                os.makedirs(folder_extension)
            file_path = os.path.join(folder_extension, name)
            if not os.path.exists(file_path):
                try:
                    self.status.config(text=f"Đang tải {name}...", fg="black")
                    self.root.update_idletasks()

                    response = requests.get(url, stream=True, timeout=15)
                    response.raise_for_status()
                    with open(file_path, 'wb') as f:
                        for chunk in response.iter_content(8192):
                            if chunk:
                                f.write(chunk)
                    self.status.config(text=f"Đã tải xuống {name} thành công",fg="green")
                    self.root.update_idletasks()
                    self.status.config(text="Chương trình sẵn sàng...", fg="blue")

                except Exception as e:
                    messagebox.showerror("Lỗi tải file", f"Không thể tải {name}:\n{e}")


if __name__ == "__main__":
    root = TkinterDnD.Tk()
    app = SFXProUnified(root)
    if app.check_files():
        root.mainloop()
    else:
        root.destroy()